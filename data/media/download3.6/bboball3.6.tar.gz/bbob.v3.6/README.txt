BBOB Black-Box Optimization Benchmarking

is concerned with providing the tools to generate and present unified
benchmarking results. Provided are in particular

* benchmark functions description and source code
* description of the experimental procedure
* tools for post-processing the resulting data into tables and graphs (to
come).

directories:
  c: benchmark functions, example experiment scripts in c
  matlab: benchmark functions, example experiment scripts in matlab 
  python: post-processing utilities
  latextemplates: templates used for the generation of papers
  docs: documentations
