/* NSGA-II routine (implementation of the 'main' function) */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <unistd.h>

#include "global.h"
#include "rand.h"

#include <limits.h>
#include "../BBOB-2013/bbobStructures.h"

#define USEDCN    0
#define POPSIZE   8
#define ETA_MUT   100
#define ETA_CROSS 15
#define PCROSS    1
#define NOBJS     2

int withDCN = USEDCN;
int nreal, nbin, nobj, ncon, popsize;
double pcross_real, pcross_bin, pmut_real, pmut_bin, eta_c, eta_m;
int ngen;
int nbinmut, nrealmut, nbincross, nrealcross;
int *nbits;
double *min_realvar, *max_realvar;
double *min_binvar, *max_binvar;
int bitlength;

void NSGAII(double(*fitnessfunction)(double*), unsigned int dim, double ftarget, double maxFuncEvals) {
    int i;
    char stoppingCriteria;
    double countFuncEvals;
    population *parent_pop;
    population *child_pop;
    population *mixed_pop;

    popsize = POPSIZE;
    ngen = (int)floor(maxFuncEvals/(double)popsize);
    nobj = NOBJS;
    ncon = 0;
    nreal = dim;
    if (nreal != 0) {
        min_realvar = (double *) malloc(nreal * sizeof (double));
        max_realvar = (double *) malloc(nreal * sizeof (double));
        for (i = 0; i < nreal; i++) {
            min_realvar[i] = -5.0;
            max_realvar[i] = +5.0;
        }
        pcross_real = PCROSS;
        pmut_real = 1/(float)dim;
        eta_c = ETA_CROSS;
        eta_m = ETA_MUT;
    }
    nbin=0; nbinmut=0; nrealmut=0; nbincross=0; nrealcross=0;
    
    parent_pop = (population *) malloc(sizeof (population));
    child_pop = (population *) malloc(sizeof (population));
    mixed_pop = (population *) malloc(sizeof (population));
    allocate_memory_pop(parent_pop, popsize);
    allocate_memory_pop(child_pop, popsize);
    allocate_memory_pop(mixed_pop, 2 * popsize);
    
    randomize();
    initialize_pop(parent_pop);
    // Initialization done, now performing first generation
    //decode_pop(parent_pop);
    evaluate_pop(parent_pop, fitnessfunction, withDCN);
    countFuncEvals = popsize;
    assign_rank_and_crowding_distance(parent_pop);
    
    //for (i = 2; i <= ngen; i++) {
    stoppingCriteria = 0;
    while ( (stoppingCriteria == 0) && (countFuncEvals < maxFuncEvals) ) {
        selection(parent_pop, child_pop); // binary tournament selection and SBX crossover
        mutation_pop(child_pop); // polynomial mutation
        //decode_pop(child_pop);
        evaluate_pop(child_pop, fitnessfunction, withDCN);
        countFuncEvals += popsize;
        merge(parent_pop, child_pop, mixed_pop);
        fill_nondominated_sort(mixed_pop, parent_pop);
        
        // Added to stop soon when integrated into COCO
        for (i=0; i<popsize; i++)
            if (parent_pop->ind[i].obj[0] <= ftarget) {
                stoppingCriteria = 1; // should stop if already reached the best target
                break;
            }
    }
    
    // Generations finished, now reporting solutions
    
    if (nreal != 0) {
        free(min_realvar);
        free(max_realvar);
    }

    deallocate_memory_pop(parent_pop, popsize);
    deallocate_memory_pop(child_pop, popsize);
    deallocate_memory_pop(mixed_pop, 2 * popsize);
    free(parent_pop);
    free(child_pop);
    free(mixed_pop);
//    printf("\n Routine successfully exited \n");
//    return (0);
}
