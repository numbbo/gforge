/* Routine for evaluating population members  */

# include <stdio.h>
# include <stdlib.h>
# include <math.h>

# include "global.h"
# include "rand.h"

#include "../BBOB-2013/bbobStructures.h"

/* Routine to evaluate objective function values and constraints for a population */
void evaluate_pop (population *pop, double(*fitnessfunction)(double*), int withDCN) {
    int i;
    for (i=0; i<popsize; i++) {
        evaluate_ind (&(pop->ind[i]), fitnessfunction);
        if (withDCN==0)
          pop->ind[i].obj[1] = 0.0; // zero DCN
    }
    
    if (withDCN != 0) {
    // Compute the DCN objective
       double minbuf, newbuf, maxDCN;
       double temp;
       //distbuf = (double*)malloc(popsize*sizeof(double));
       int k, j;
       maxDCN = 0.0;
       for (i=0; i<popsize; i++) {
         minbuf = INF; newbuf = INF;
         for (k=0; k<popsize; k++) {
           if (i != k) {
             temp = 0.0;
             for (j=0; j<nreal; j++) {
               temp += pow(pop->ind[i].xreal[j] - pop->ind[k].xreal[j], 2.0);
             }
             newbuf = sqrt(temp);
           } else {
             newbuf = INF;
           }
         //Determine the min distance
           minbuf = (newbuf < minbuf) ? newbuf : minbuf;
         }
         pop->ind[i].obj[1] = minbuf;
         maxDCN = (minbuf > maxDCN) ? minbuf : maxDCN; //keep updated for the largest DCNobj value
       }
     //Calculate the DCNobj (for a minimization obj)
       for (i=0; i<popsize; i++)
         pop->ind[i].obj[1] = - pop->ind[i].obj[1] + maxDCN + EPS; 
    }
    
    return;
}

/* Routine to evaluate objective function values and constraints for an individual */
void evaluate_ind (individual *ind, double(*fitnessfunction)(double*)) {
    int j;
  //test_problem (ind->xreal, ind->xbin, ind->gene, ind->obj, ind->constr);
    ind->obj[0] = fitnessfunction(ind->xreal);
    
//    ind->obj[1] = 0; // zero DCN
    
    if (ncon==0) {
        ind->constr_violation = 0.0;
    } else {
        ind->constr_violation = 0.0;
        for (j=0; j<ncon; j++)
            if (ind->constr[j]<0.0)
                ind->constr_violation += ind->constr[j];
    }
    return;
}
