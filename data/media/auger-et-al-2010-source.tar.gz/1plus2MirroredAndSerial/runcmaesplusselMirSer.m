function [XMIN, FMIN, COUNTEVAL, STOPFLAG, OUT, BESTEVER] = ...
            runcmaesplusselMirSer(FUN, DIM, ftarget, maxfunevals)
% MY_OPTIMIZER(FUN, DIM, ftarget, maxfunevals)


  clear opts; 
  
  opts.mirrored = 1;
  opts.serial = 1;
  
  % speed and output options
  opts.stopfitness = ftarget;
  % opts.maxiter = '100 + 1000 * N * sqrt(N/popsize)'; --> does not make sense in serial selection scheme
  opts.maxfunevals = maxfunevals; % instead of maxiter
  % opts.TolFun = 1e-8;  
  
  opts.Display = 'off';
  opts.Plotting='off';
  opts.Saving= 'off';
  opts.SaveModulo = '2';
  
  FMIN=inf;

  nrestarts=0;
  
  
  while(FMIN > ftarget) && (opts.maxfunevals > 1)

      [XMIN, FMIN, COUNTEVAL, STOPFLAG, OUT, BESTEVER] = cmaesplusselMirSer(FUN, 8*rand(DIM, 1) - 4, 2, opts);
      %cmaesplussel(FUN, ['8*rand(' num2str(DIM) ', 1) - 4'], 2, opts);
      opts.maxfunevals=opts.maxfunevals - COUNTEVAL;

      nrestarts=nrestarts+1;
  end
  disp(['nbr restarts= ' num2str(nrestarts)]);
