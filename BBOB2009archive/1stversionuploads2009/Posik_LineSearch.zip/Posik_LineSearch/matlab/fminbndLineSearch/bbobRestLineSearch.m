function [x, ilaunch] = bbobRestLineSearch(FUN, ...
    DIM, ftarget, outermaxfunevals, innermaxfunevals, varargin)

fevals = 0;

% multistart such that ftarget is reached with reasonable prob.
for ilaunch = 1:100  % relaunch optimizer up to 100 times

    % Initialize
    x0 = -5 + 10*rand(DIM, 1); % Random start solution

    opts.MaxFunEvals = min( outermaxfunevals-fgeneric('evaluations'), innermaxfunevals );
    opts.Display = 'off';

    % try minLineSearch
    [x] = bbobMinLineSearch(FUN, x0, ftarget, opts, varargin{:});

    if (fgeneric('fbest') < ftarget) || (fgeneric('evaluations') >= outermaxfunevals),
        break;
    end
end
