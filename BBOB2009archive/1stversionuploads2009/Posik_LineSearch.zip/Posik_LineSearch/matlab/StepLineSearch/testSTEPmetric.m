% x0 = 0;
% y0 = 0;

x = 10;
y = -20;

fmin = 0;
eps = 1e-8;
f = fmin - eps;

a = (y - 2*f + 2*sqrt(f*(f - y))) / x^2
a2 = (y - 2*f - 2*sqrt(f*(f - y))) / x^2
b = y / x - a*x;
b2 = y / x - a2*x;
xopt = -b/2*a
xopt2 = -b2/2*a2

xpts = 0:0.05:1;
ypts = a*(xpts.^2)+b*xpts;
% y2pts = a2*(xpts.^2)+b2*xpts;
plot(xpts, ypts, 'b')
% plot(xpts, y1pts, 'b', xpts, y2pts, 'r')