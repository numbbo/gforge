function [x, ilaunch] = bbobRestSTEPLineSearch(FUN, ...
    DIM, ftarget, outermaxfunevals, innermaxfunevals, varargin)

    fevals = 0;
    
    % multistart such that ftarget is reached with reasonable prob.
    for ilaunch = 1:100  % relaunch optimizer up to 100 times

        opts.MaxFunEvals = min( outermaxfunevals-fevals, innermaxfunevals );
        opts.Display = 'off';
        opts.MaxDifficulty = 2e6;
        
        % Initialize
        if mod(ilaunch-1, floor(1 + 3 * rand)) == 0
            x0 = -5 + 10*rand(DIM, 1); % Random start solution 
        else
            x0 = x + 0.2*randn(DIM, 1); 
        end
        
        % try minDirectLineSearch
        [x fmin myfevals] = bbobMinSTEPLineSearch(FUN, ...
            x0, ftarget, opts, varargin{:});
        fevals = fevals + myfevals;

        if ...
                (fmin < ftarget) || ...
                (fevals >= outermaxfunevals),
            break;
        end
        % if useful, modify more options here for next launch
    end
    
end