function [xmin, fmin, fevals, exitflag, xp, ints] = ...
    min1DSTEP(func, lims, opts, varargin)
%
% MIN1DSTEP Optimization of 1-D function using the STEP method.
%
% Package: HOAtbx
%
% Description:
%
%   [xmin, fmin, fevals] = min1DSTEP(func, bounds, opts, varargin)
%      Function minimizes a 1-dimensional function. It requires:
%      func ... A string or function handle of the optimized function with
%               1 argument
%      lims ... A pair of numbers, lower and upper limit of the interval
%      opts ... Structure with options.
%               opts.TolX
%                   Intervals lower than TolX are not divided anymore.
%               opts.Ftarget
%                   The value to reach.
%               opts.MaxFunEvals
%                   The maximum number of allowed function evaluations.
%               opts.MaxDifficulty
%                   The maximum difficulty for interval division. If an
%                   interval can lead to improvement only if the function
%                   was harder than MaxDifficulty, then do not consider it.
%

interactive = 0;
fevals = 0;

%% Initialize parameters
if ~exist('func', 'var') | isempty(func), error('Function not set.'); end
if ~exist('lims', 'var') | isempty(lims), error('Limits not set.'); end
if numel(lims) ~= 2, error('Limits not set properly, should be a vector of 2 numbers'); end
if ~exist('opts','var')   | isempty(opts), opts = struct; end
if iscell(opts), opts = struct(opts); end

if ~isfield(opts,'TolX'), opts.TolX = 1e-11; end
if ~isfield(opts,'Eps'), opts.Eps = 1e-8; end
if ~isfield(opts,'MaxIter'), opts.MaxIter = inf; end
if ~isfield(opts,'MaxFunEvals'), opts.MaxFunEvals = 1000; end
if ~isfield(opts,'Ftarget'), opts.Ftarget = -inf; end
if ~isfield(opts,'MaxDifficulty'), opts.MaxDifficulty = inf; end

% GR = (1+sqrt(5))/2;

%% Initialize data structures
% Array xp: the sampled data points and their fitness
% Initialize by evaluating both limits
xp(1,:) = [lims(1) feval(func, lims(1))];
xp(2,:) = [lims(2) feval(func, lims(2))];
fevals = fevals + 2;
[fmin, imin] = min( xp(:,2) );
xmin = xp( imin, 1 );

% Array ints: the definition of intervals
% Each row is one interval, a pair of indices to xp array, the interval
% size and the difficulty of the interval.
% Initialize by setting the interval from 1st to the 2nd array.
a = difficulty( xp(1,:), xp(2,:) );
ints = [1 2 abs(xp(1,1)-xp(2,1)) a];

%% Start of the algorithm
while true
    
    % Test termination conditions
    if fmin < opts.Ftarget, exitflag = 'Ftagret'; break; end
    if fevals >= opts.MaxFunEvals, exitflag = 'MaxFunEvals'; break; end
    
    % Find intervals with sufficient size
    indSize = (ints(:,3) > opts.TolX);
    % Test termination condition
    if sum(indSize) == 0, exitflag = 'TolX'; break; end
    
    % Find intervals with allowed difficulty index
    indDif = (ints(:,4) <= opts.MaxDifficulty);
    % Test termination condition
    if sum(indDif) == 0; exitflag = 'MaxDifficulty'; break; end
    
    % Combine them
    ind = find(indSize & indDif);
    if isempty(ind); exitflag = 'TolX and MaxDifficulty'; break; end
    
    % Select the least difficult interval
    [foo, imin] = min(ints(ind,4));
    iBest = ind(imin);
    
    % Generate new point by halving the interval and evaluate it
    % Get the indices of left and right points
    il = ints(iBest,1);
    ir = ints(iBest,2);
    xnew = ( xp(il,1) + xp(ir,1) ) / 2;
%     xnew = ( (GR-1)*xp(il,1) + xp(ir,1) ) / GR;
    fnew = feval( func, xnew ); 
    fevals = fevals + 1;
    % Index of the middle point
    im = fevals;
    
    % fevals is the index of the last evaluated point
    xp(fevals,:) = [xnew fnew];
    
    % Make place for a new interval, the other will take the place of the
    % old interval. fevals-1 is the index of last added interval.
    ints(end+1,:) = zeros( 1, 4 );
    % Assign new values defining the intervals
    % Copy the right limit to the new interval
    ints(fevals-1, 2) = ir;
    % Make the new point the right limit of the old interval and the left
    % limit of the new interval
    ints(iBest, 2) = im;
    ints(fevals-1,1) = im;
    % Compute the interval sizes
    ints(iBest, 3) = abs( xp(im,1) - xp(il,1) );
    ints(fevals-1, 3) = abs( xp(ir,1) - xp(im, 1) );
    
    % Update fmin, xmin
    if fnew < fmin,
        fmin = fnew;
        xmin = xnew;
        % If fmin improved, we need to recompute the difficulty of all
        % intervals!
        for i = 1:fevals-1,
            a = difficulty( xp(ints(i,1),:), xp(ints(i,2),:));
            ints(i,4) = a;
        end
    else
        % If fmin did not improve, we need to compute the difficulty only for
        % the two newly created intervals
        ints(iBest,4) = difficulty( xp(ints(iBest,1),:), xp(ints(iBest,2),:));
        ints(fevals-1,4) = difficulty( xp(ints(fevals-1,1),:), xp(ints(fevals-1,2),:));
    end
    
end

%% Helper function
    function [a,b,c] = difficulty(x1, x2)
        % x1 and x2 are 1x2 vectors of data points given by their x-values
        % and fitnesses.
        % The function interpolates the points x1 and x2 by a parabola. The
        % third defining criterion of the parabola is that it must at least
        % touch the fitness value fmin-eps.
        % Function returns 2 * the second derivative of the parabola
        % ax^2+bx+c, i.e. the coefficient a.
        
        x = x2(1) - x1(1);
        y = x2(2) - x1(2);
        f = fmin - opts.Eps - x1(2);
        
        a = (y - 2*f + 2*sqrt(f*(f - y))) / x^2;
        if nargout > 1, b = y/x - a*x; end
        if nargout > 2, c = x1(2); end
    end
end