clc; clear;

bbobpath = pwd;
ind = max(strfind(bbobpath,'\'));
bbobpath(ind:end) = [];

outerstr = '1e4*dim';
innerstr = '1e4*dim';

addpath([bbobpath '\matlab']);  % should point to fgeneric.m etc.
dirnamesuffix = sprintf('%stil%s',innerstr, outerstr);
dirnamesuffix = strrep(dirnamesuffix, '*dim', 'D');
datapath = [bbobpath '\results\RosenbrockLS' dirnamesuffix];  % different folder for each experiment
opt.algName = 'Rosenbrock''s local search';  % different name for each experiment
opt.comments = ['restarts up to 100, '...
    sprintf('outermaxfevals %s, inner maxfunevals %s',outerstr,innerstr)];
opt.inputFormat = 'row';

more off;  % in octave pagination is on by default

t0 = clock;
rand('state', sum(100 * t0));

dims = [2,3,5,10,20];%,40];
funcs = benchmarks('FunctionIndices');
instances = [1:5 1:5 1:5];

startdim = 20;
startifun = 8;
startinstance = 14;

for dim = dims,  % small dimensions first, for CPU reasons
    if dim < startdim, continue; end
    for ifun = funcs,
        if (dim == startdim && ifun < startifun), continue; end
        for iinstance = 1:numel(instances),  % first 5 function instances, three times
            if (dim == startdim && ifun == startifun && iinstance < startinstance),
                continue;
            end
            fgeneric('initialize', ifun, instances(iinstance), datapath, opt);

            [myx, mylaunch] = bbobRestRosenbrockLS(@fgeneric, dim, fgeneric('ftarget'), ...
                eval(outerstr), eval(innerstr));

            disp(sprintf(['  f%d in %d-D, instance %d: FEs=%d, #launches=%d' ...
                ' fbest-fopt=%.4e, elapsed time [h]: %.2f'], ...
                ifun, dim, iinstance, ...
                fgeneric('evaluations'), ...
                mylaunch, ...
                fgeneric('fbest') - fgeneric('ftarget') + 1e-8, ...
                etime(clock, t0)/60/60));
            fgeneric('finalize');
        end
        disp(['      date and time: ' num2str(clock, ' %.0f')]);
    end
    disp(sprintf('---- dimension %d-D done ----', dim));
end
