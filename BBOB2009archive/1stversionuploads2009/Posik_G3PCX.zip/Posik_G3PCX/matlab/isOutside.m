function out = isOutside(x)
% Checks if points are outside the (-5,5) interval in any dim.
    out = any( x > 5 | x < -5 , 1);
end