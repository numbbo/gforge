function m = shapematrix(x, center)

    [D,N] = size(x);
    xc = x - repmat(center,1,N);
    m = (xc*xc') / (N-1);
end