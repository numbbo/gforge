function x = randCauchyNormalized( D, N, tau )

% Sample the norms using standard 1D Cauchy distribution
r = cauchyrnd(0,1, 1,N);
% Normalize them, if tau is present
if nargin > 2 && ~isempty(tau),
    cq = cauchyinv((1+tau)/2, 0, 1) ;
    r = r / cq;
end
% Sample direction vectors uniformly distributed on unit sphere
x = randn( D, N );
lengths = sqrt( sum(x.^2,1) );
x = x ./ lengths(ones(D,1),:);
% Multiply the unit vectors by the cauchy-distributed norms
x = x .* r(ones(D,1),:);

end