function p = Parameters(p)
% 
% Parameters 'object'. Adds several methods to struct 'p' for better
% retrieving of values.
%
% Package: HOAtbx
%
% Synopsis:
%
%   1) Create ordinary struct, e.g.
%       p.first.second.third.fourth.fifth.sixth = 1;
%       p.sixth = 2;
%       p.fifth.sixth = 3;
%       p.first.second.fifth.sixth = 4;
%
%   2) Construct the 'object':
%       p = Parameters(p)
%           This adds to 'p' several methods handles. CAUTION: If you
%           modify the p struct after this call, the methods would not have
%           access to the added fields. You must recreate the struct.
%
%   3) Access the fields using those methods.
%
%   Simple access:
%       p.getExact('first.second.third.fourth.fifth.sixth') returns 1. Throws
%           exception if any of the fields are incorrect.
%
%   Simple access with default value:
%       p.get('first.second.huhu',100) returns 100, if the field
%           p.first.second.huhu is not set.

    if isempty(p) || ~isstruct(p),
        error('HOAtbx:MissingArgument','No parameters structure given.');
    end

    if isfield(p,'context'),
        context = p.context;
    else
        context = '';
    end

    p.getValueForAbsKey  = @getValueForAbsKey;
    p.get                = @get;
    p.getNoDefault       = @getNoDefault;

%     p.dump          = @dump;
%     p.save          = @save;
%     p.load          = @load;
%     p.toString      = @toString;

    function val = get(varargin)
        if nargin < 2,
            error('HOAtbx:WrongNumberOfArguments','Function get needs at least 2 argumemts: key and default value.');
        end
        
        if nargin > 4,
            error('HOAtbx:WrongNumberOfArguments','Function allows at most 4 arguments: fixed context, inheriting context, key, and default value.');
        end
        
        try
            val = getNoDefault(varargin{1:end-1});
        catch ME
            if strcmp(ME.identifier,'HOAtbx:UndeterminedValue'),
                val = varargin{end};
            else
                rethrow ME;
            end
        end
    end

    function val = getNoDefault(varargin)

        if nargin < 1,
            error('HOAtbx:WrongNumberOfArguments','Function get needs at least 1 argumemts: key.');
        end
        
        if nargin > 3,
            error('HOAtbx:WrongNumberOfArguments','Function allows at most 3 arguments: fixed context, inheriting context, and key.');
        end

        switch nargin,
            case 1,
                fixed = '';
                inher = '';
                key = varargin{1};
            case 2,
                fixed = '';
                inher = varargin{1};
                key = varargin{2};
            case 3,
                fixed = varargin{1};
                inher = varargin{2};
                key = varargin{3};
        end
        
        val = getOrInherit(fixed,inher,key); % Throws exception if value not found.
        
    end

%     function val = get(key, defval)
%         abskey = [context key];
%         [val, goodSeq] = getValueForAbsKey(abskey);
%         
%         % If value found...
%         if ~isnumeric(val) || ~isnan(val), return; end
%         
%         % Try to use default value
%         if exist('defval','var'),
%             val = defval;
%         else
%             error('HOAtbx:UndeterminedValue','Cannot determine value for the key %s.',key);
%         end
%     end

    function val = getOrInherit(fixed, inher, key)
        found = false;
        
        while ~found,
            abskey = [dotAfter(context) dotAfter(fixed) dotAfter(inher) key];
            try
                val = getValueForAbsKey(abskey);
                found = true;
            catch ME
                if strcmp(ME.identifier,'MATLAB:nonExistentField'),
                    % Key was not found, try to modify inher part
                    % If inher is empty, the last possibility was already
                    % tried, throw exception
                    if isempty(inher),
                        throw(MException('HOAtbx:UndeterminedValue','The key does not exist; neither exact key, nor in inheriting area.'));
                    end
                    % Get the index of last dot
                    lastdotind = find(inher == '.', 1,'last');
                    if isempty(lastdotind),
                        % No dot in inher, try the last possibility - empty
                        % inher
                        inher = '';
                    else
                        % Strip off the part of inher after the last dot (incluslively).
                        inher = inher(1:lastdotind-1);
                    end
                else
                    % A different exception was caught
                    rethrow(ME);
                end
            end
        end
    end
    
    function val = getValueForAbsKey(key) % throws MATLAB:nonExistentField
        val = [];
        
        seq = regexp(key,'[^.]+','match');
        myp = p;
        for i = 1:numel(seq),
            myp = myp.(seq{i});
        end
        val = myp;
    end

    function str = dotBefore(str)
        if ~isempty(str),
            str = ['.' str];
        else
            str = '';
        end
    end

    function str = dotAfter(str)
        if ~isempty(str),
            str = [str '.'];
        else
            str = '';
        end
    end

    function dump(fileDesc)
        if ~exist('fileDesc','var') || isempty(fileDesc),
            fileDesc = 1; % Standard output
        end
        
        keys = fieldnames(p);
        lengths = cellfun( @(str) numel(str), keys );
        maxlen = max(lengths);

        for i = 1:numel(keys),
            fprintf(fileDesc, ...
                '%s%s = %s\n', ...
                strrep(keys{i},'_','.'), ...
                spaces(maxlen-numel(keys{i})), ...
                toString(p.(keys{i})) );
        end
        
    end

    function save(filename)
        
        fd = fopen(filename,'w');
        
        dump(fd);
        
        fclose(fd);
    end

    function load(filename, clearParams)
        
        if exist('clearParams','var') && clearParams,
            p = struct;
        end

        fd = fopen(filename,'r');
        
        while ~feof(fd),
            str = fgets(fd);
            [keystr,str] = strtok(str,'=');
            valstr = strtok(str,'=');
            
            keystr = strtrim(keystr);
            valstr = strtrim(valstr);
            key = strrep(keystr,'.','_');
            val = toVal(valstr);
            
            p.(key) = val;
        end
        
        fclose(fd);
    end

    function sp = spaces(n)
        sp = char(' '*ones(1,n));
    end
            
    function str = toString(val)
        if ischar(val),
            % One string
            str = val;
        elseif iscell(val),
            % Cell array of strings
            str = val{1};
            for i = 2:numel(val),
                str = [str ',' val{i}];
            end
        elseif isfloat(val) && all(abs(round(val)-val) < eps),
            % Integer of vector of integers
            str = sprintf('%d,', val);
            str = str(1:end-1);
        elseif isfloat(val),
            % Double or vector of doubles
            str = sprintf('%.3f,', val);
            str = str(1:end-1);
        else
            error('HOAtbx:UnsupportedDataType','Wrong data type.');
        end
    end

    function val = toVal(str)
        remstr = str;
        i = 0;
        while ~isempty(remstr),
            i = i+1;
            [valstr, remstr] = strtok(remstr,',');
            parsedval = str2double(valstr);
            if isnan(parsedval),
                val(i) = {valstr};
            else
                val(i) = parsedval;
            end
        end
    end

end