function [xmin, fmin, fevals, exitflag, output] = ...
    bbobMinCauchyEDA(FUN, x0, ftarget, opts, outOfBndsFcn)

    D = size(x0,1);

    if nargin < 4 || isempty(opts), opts = optimset(); end
    if nargin < 5, outOfBndsFcn = @(x) false(1,size(x,2)); end
    defopts = struct(...
        'MaxFunEvals', 5e4*D, ... %min(3e3*D, opts.MaxFunEvals), ...
        'TolFun', 0, ...
        'TolX', 1e-6, ...
        'Display', 'off' ...
        );
    opts = optionsOrDefaults(opts, defopts);
    exitflag = [];

    verbosity = 0;
    if strcmp(opts.Display, 'final'), verbosity = 1; end
    if strcmp(opts.Display, 'iter'), verbosity = 2; end        

    % Set the parameters
    if D <= 4,
        k = sqrt(D) * (0.3 + 0.25*D);
    else
        k = sqrt(D) * (1.45 + 0.013*D);
    end
    N = ceil((D^1.37) * 10^1.06);
    tau = 0.3;
    
    mu = x0; sig = 0.1*ones(1,D)'; R = eye(D);
    baseSampleFunc = @(D,N) randCauchyNormalized(D, N, tau);
    fevals = 0;
    
    while true,
    
        % Sample new population
        x = sampleAndTransform( baseSampleFunc, N, mu, sig, R );
        x(:,outOfBndsFcn(x)) = [];
        while size(x,2) < N,
            x1 = sampleAndTransform( baseSampleFunc, N, mu, sig, R );
            x1(:,outOfBndsFcn(x1)) = [];
            x = [x x1];
        end
        x = x(:,1:N);
        
        % Evaluate
        f = feval( FUN, x );
        fmin = min(f);
        fevals = fevals + numel(f);
        
        % Select
        [isel,idis] = selTruncation(f, tau);
        
        % Create model
        mu = mean( x(:, isel), 2 );
        shapemat = shapematrix( x(:, isel), mu );
        [Rnew,signew] = estimateShape(shapemat);

        signew = k * signew ;
        signew(signew < 1e-7) = 1e-7;

        % Possible update, not used here
        aR = 0.; R = aR*R + (1-aR)*Rnew;
        asig = 0.; sig = asig*sig + (1-asig)*signew;        
        
        if verbosity >= 2,
            fprintf('Fevals: %d   min(f)-fopt: %.3e   max(f)-min(f): %.3e   TolX: %.3e\n', ...
                fevals, ...
                fmin-ftarget+1e-8, ...
                max(f)-min(f), ...
                max(abs(sig)) );
        end
        
        if (fmin <= ftarget), exitflag = 'StopFitness'; break; end
        if (fevals >= opts.MaxFunEvals), exitflag = 'MaxFunEvals'; break; end
        if (max(f) - min(f) < opts.TolFun), exitflag = 'TolFun'; break; end
        if (max( abs(sig) ) < opts.TolX), exitflag = 'TolX'; break; end
        
    end
           
    [fmin imin] = min(f);
    xmin = x(:,imin);

    output.FitnessDiff = fmin-ftarget;
    output.FuncCount = fevals;
    output.TolF = max(f) - min(f);
    output.TolX = max(max(x,[],2)-min(x,[],2));

    if verbosity >= 1,
        fprintf('Finished. Fevals: %d   Fmin: %.3f\n', fevals, min(f));
    end
    
end