function opts = optionsOrDefaults(opts, defopts)

fields = fieldnames(defopts);
for i = 1:length(fields),
    field = fields{i};
    if ~isfield(opts, field)
        opts.(field) = defopts.(field);
    end
end

end