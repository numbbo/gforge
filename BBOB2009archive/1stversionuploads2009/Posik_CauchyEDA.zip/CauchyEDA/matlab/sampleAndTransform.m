function x = sampleAndTransform(baseSampleFunc, N, mu, sig, R);

    D = numel(mu);
    x = feval( baseSampleFunc, D, N );

    x = diag(sig) * x;
    x = R * x;
    x = x + repmat(mu,1,N);
    
end