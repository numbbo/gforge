function x = cauchypolarrnd(dim,n)
%
% ch2polarrnd Generates 'n' 'dim'-dimensional random points (column
% vectors) by the following procedure:
% (1) sample the radiuses using cauchy distribution
% (2) sample unit vectors from dim-dimensional space
% (3) use the radiuses to enlarge the unit vectors
%

% Sample the norms using standard 1D Cauchy distribution
r = cauchyrnd(0,1,1,n);
% Sample direction vectors uniformly distributed on unit sphere
x = randn(dim, n);
lengths = sqrt(sum(x.^2,1));
x = x ./ lengths(ones(dim,1),:);
% Multiply the unit vectors by the cauchy-distributed norms
x = x .* r(ones(dim,1),:);