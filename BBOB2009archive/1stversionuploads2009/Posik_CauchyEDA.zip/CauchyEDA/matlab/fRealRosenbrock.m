function f = fRealRosenbrock(x, varargin)
%
% FREALROSENBROCK Evaluation function for 2D real vector
%

x1 = x(1:end-1,:);
x2 = x(2:end,:);
f = sum( 100.*(x2-x1.^2).^2 + (1-x1).^2, 1 );
