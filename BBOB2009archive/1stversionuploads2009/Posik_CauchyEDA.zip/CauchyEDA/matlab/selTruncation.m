function [isel, idis] = selTruncation(f, tau)
%
% selTruncation Truncation selection with parameter tau.
%

[foo, isort] = sort(f);
n = round( tau*length(f) );
isel = isort(1:n);
idis = isort(n+1:end);
