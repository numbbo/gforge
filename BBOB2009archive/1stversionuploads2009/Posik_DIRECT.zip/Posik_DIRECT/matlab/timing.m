% runs the timing experiment for MY_OPTIMIZER. fgeneric.m
% and benchmarks.m must be in the path of MATLAB/Octave

% addpath('PUT_PATH_TO_BBOB/matlab');  % should point to fgeneric.m etc.

more off;  % in octave pagination is on by default
opt.inputFormat = 'col';


timings = [];
runs = [];
dims = [];
for dim = [2,3,5,10,20,40]
    nbrun = 0;
    ftarget = fgeneric('initialize', 8, 1, 'tmp', opt);
    mytic = tic;
    while toc(mytic) < 30  % at least 30 seconds
        [myx, mylaunch] = bbobRestDirect(@fgeneric, dim, fgeneric('ftarget'), ...
                1e5, 1e5);

        nbrun = nbrun + 1;
    end  % while
    timings(end+1) = toc / fgeneric('evaluations');
    dims(end+1) = dim;    % not really needed
    runs(end+1) = nbrun;  % not really needed
    fgeneric('finalize');
    disp([['Dimensions:' sprintf(' %11d ', dims)]; ...
        ['      runs:' sprintf(' %11d ', runs)]; ...
        [' times [s]:' sprintf(' %11.1e ', timings)]]);
end
fid = fopen('timing.txt','w');
fprintf(fid, ['Dimensions:' sprintf(' %11d ', dims) '\n']);
fprintf(fid, ['      runs:' sprintf(' %11d ', runs) '\n']); 
fprintf(fid, [' times [s]:' sprintf(' %11.1e ', timings) '\n']);
fclose(fid);

