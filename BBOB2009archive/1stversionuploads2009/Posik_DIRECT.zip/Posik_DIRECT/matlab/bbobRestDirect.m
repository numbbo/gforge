function [xbsf, ilaunch] = bbobRestDirect(FUN, ...
    DIM, ftarget, outermaxfunevals, innermaxfunevals, varargin)

fevals = 0;
x = -inf(DIM,1);
xbsf = x;
fbsf = inf;
initway = 'whole';

% multistart such that ftarget is reached with reasonable prob.
for ilaunch = 1:100  % relaunch optimizer up to 100 times
 
    % Prepare options for DIRECT
    diropts.ep = 1e-10;
    diropts.maxevals = min( outermaxfunevals-fevals, innermaxfunevals );
    diropts.maxits = inf;
    diropts.maxdeep = 21;
    diropts.testflag = 1; % Global optimum known
    diropts.showits = 0;  % Show info
    diropts.globalmin = ftarget - 1e-8;
    diropts.tol = 1e-8; 
    if diropts.globalmin ~= 0,
        diropts.tol = diropts.tol * 100/abs(diropts.globalmin);
    else
        diropts.tol = 100*diropts.tol;
    end
    
    % Initialize
    if strcmp(initway, 'whole')
        % Take the whole cube in the first launch
        bounds = repmat(5*[-1 1], DIM, 1);
        nimprove = 0;
    elseif strcmp(initway, 'reduced')
        % Limit the search to a smaller cube
        bounds = repmat(5*[-1 1], DIM, 1);
        x0 = 0.1*(-1 + 2*rand(DIM,1));
        indl = (x0>=0); % Add positives to the lower bounds
        indu = (x0<0);  % Add negatives to the upper bounds
        bounds(indl,1) = bounds(indl,1) + x0(indl);
        bounds(indu,2) = bounds(indu,2) + x0(indu);
    elseif strcmp(initway, 'improve')
        % Try to improve the solution found so far
        bounds = repmat(0.1^nimprove*[-1 1], DIM, 1);
        bounds = bounds + repmat(x(:),1,2);
        nimprove = nimprove + 1;
    end
 
    xold = x;
    Problem.f = FUN;
    [fmin, x, history] = DirectObj(Problem, bounds, diropts);
    fevals = fevals + history(end, 2);

    if strcmp(initway, 'whole'),
        initway = 'improve';
        fafter1it = fmin;
        xbsf = x;
        fbsf = fmin;
    else
        if fmin < fbsf,
            fbsf = fmin;
            xbsf = x;
        end
        
        if strcmp(initway, 'reduced'),
            initway = 'improve';
            if fmin < fafter1it,
                fafter1it = fmin;
                nimprove = 0;
            else
                x = xbsf;
            end
        elseif strcmp(initway, 'improve')
            initway = 'reduced'; 
        end
    end
    
    if ...
            (fbsf < ftarget) || ...
            (fevals >= outermaxfunevals),
        break;
    end
    % if useful, modify more options here for next launch
end

end