clear; clc;
dim = 1;

% DIRECT predpoklada sloupcove vektory!
% opts.tol je odchylka od optima v procentech z absolutni hodnoty optima!
pat = {'b-', 'r-', 'g--', 'k-', 'm-'};
glmins = [-0.1 -1e-6 0 1e-3 1e-2];
% glmins = [-100 -10 0 10 100];
glmins = 0;
% glmins = [0 1];
for i = 1:numel(glmins),

    opts.maxevals = 10000;
    opts.maxits = inf;
    opts.maxdeep = 40;
    opts.testflag = 1; % Global optimum known
    opts.showits = 1;  % Show info
    opts.globalmin = glmins(i);
    opts.tol = 1e-8; % 1e-3 * 100/abs(opts.globalmin)
    
    opts1 = opts;
    if opts.globalmin ~= 0,
        opts1.tol = opts.tol * 100/abs(opts.globalmin);
    else
        opts1.tol = 100*opts.tol;
    end
%     opts1.testflag = 0;

    problem.f = @(x,b) sum((x-1.5).^2,1)+b;
    problem.f = @(x,b) frosen(x) + b;
    problem.f = @(x,b) 0.1*(x-1).^2 - cos(2*pi*(x-1)) + 1 + b;
    bounds = repmat(5*[-1 1], dim, 1);

%     [fmin,xmin,hist] = DirectObjMod(problem, bounds, opts, opts.globalmin)
    [fminor, xminor, histor, c] = DirectObj(problem,bounds,opts1, opts.globalmin);
%     [fminor, xminor, histor] = Direct(problem,bounds,opts1, opts.globalmin)
    hist = histor;
%     if i > 1 && size(hist,1) ~= size(iters,1), keyboard; end
%     
%     iters(:,i) = hist(:,1);
%     fevals(:,i) = hist(:,2);
%     fvals(:,i) = hist(:,3);
    
     semilogy(hist(:,2), hist(:,3)-opts.globalmin, pat{i}); hold on;
%     semilogy(hist(:,2), hist(:,3)-opts.globalmin, 'b-', ...
%         histor(:,2), histor(:,3)-opts.globalmin, 'r-');
    title(sprintf('b=%f',opts.globalmin))
    
%     pause;
end