function MY_OPTIMIZER(FUN, DIM, ftarget, maxTime)
% Notice that maxfunevals have been replace by maxTime. Therefore, stop condition is a maximum time budget instead of a maximum number of evaluations.
% In order to be run, the file cmaes.m, available at http://www.lri.fr/~hansen/cmaes_inmatlab.html, should be in the same directory

startTime = time();

%PARÁMETROS MODIFICABLES
maxPopSize = 100;
alfa = 0.5;
initialAlfa = alfa;
numNeighbours = 20;
thresholdDist = 1e-2;
thresholdF = 1e-8;

factorEvals = 0.5;
minbound = -5;
maxbound = 5;
maximumRadio = maxbound - minbound; %box contraints
maxfunevals = Inf;
precision = 1e-8;
bitsPerVariable = 20;

numReinicios = 1;
maxEvals = 100;
k = 0;
numEvals = 0;
pob=[];
fitness=[];
crowding = [];
indexCrowding = [];
[pob fitness crowding indexCrowding] = initiatePob(maxPopSize, DIM, minbound, maxbound, FUN);

x0=rand(DIM,1) * maximumRadio + minbound;
newX0 = x0;
bestFmin = feval(FUN, x0);
bestX = x0;
currentBest = newX0;
currentBestF = bestFmin;
numEvals = numEvals + 1;

opts = cmaes('defaults');

%The following sentence is the result of a misinterpretation. It should be 'opts.StopFitness = ftarget;'
opts.StopFitness = ftarget+precision;
opts.LBounds = minbound;
opts.UBounds = maxbound;
opts.Restarts = 0;
opts.EvalInitialX = 'no';
opts.MaxFunEvals=maxfunevals - numEvals;

opts.DispModulo=Inf;
opts.SaveVariables = 'off';
opts.LogPlot = 'off';
opts.LogModulo = Inf;
opts.LogTime=100000;
opts.DispFinal='off';
opts.SaveFileName='';
opts=rmfield(opts, 'SaveFileName');
[x0, fmin, counteval, stopflag, out, bestever]= cmaes(FUN, newX0, maximumRadio/3, opts);
numEvals = numEvals + counteval;
[pob fitness crowding indexCrowding] = insert2(pob, fitness, crowding, indexCrowding, x0, fmin, maxPopSize);

if fmin < bestFmin
	bestFmin = fmin;
	bestX = x0;
end

if fmin < currentBestF
	currentBest = x0;
	currentBestF = fmin;
end

%The following condition is the result of a misinterpretation. It should be something like 'fgeneric('fbest') > fgeneric('ftarget')...'
while floor(abs(fgeneric('fbest') - fgeneric('ftarget')) / precision * 1e4) > 1e4 && maxTime > (time() - startTime)

	[newX0 fcs countEvals] = runMicroCHC(currentBest, 5, 0.5, maximumRadio * k / numNeighbours, maximumRadio * (k+1) / numNeighbours, minbound, maxbound, bitsPerVariable, maxEvals, FUN);
	numEvals += countEvals;

	[newSolution newfcs countEvals newPob newFitness crowding indexCrowding] = optimize(newX0, fcs, pob, fitness, crowding, indexCrowding, alfa, maxPopSize, thresholdDist, FUN);
	newX0 = newSolution;
	numEvals += countEvals;
	maxEvals = factorEvals * countEvals;
	pob = newPob;
	fitness = newFitness;

	disp(sprintf('Nuevo fitness %.4e (%.4e), consumiendo %d de %d, k %d, alfa %.4e', newfcs - fgeneric('ftarget'), fgeneric('fbest') - fgeneric('ftarget'), countEvals, numEvals, k, alfa));


	if (currentBestF - newfcs) > thresholdF

		k = 0;
		currentBestF = newfcs;
		currentBest = newSolution;
	else

		if newfcs < currentBestF
			currentBest = newSolution;
			currentBestF = newfcs;
		end

		k = mod(k + 1, numNeighbours);

		if k == 0
			thresholdDist = thresholdDist / 2;
			numReinicios++;
			alfa = initialAlfa / log(numReinicios);
			
  			currentBest=rand(DIM,1) * maximumRadio + minbound;
			currentBestF = feval(FUN, currentBest);
			[currentBest, currentBestF, counteval, stopflag, out, bestever]= cmaes(FUN, currentBest, maximumRadio/3, opts);

			if currentBestF < bestFmin
				bestFmin = currentBestF;
				bestX = currentBest;
			end

			numEvals = numEvals + counteval;
			[pob fitness crowding indexCrowding] = insert2(pob, fitness, crowding, indexCrowding, currentBest, currentBestF, maxPopSize);
		end
	end

	if newfcs < bestFmin
		bestFmin = newfcs;
		bestX = newSolution;
	end
end
end

function [newCrowding newIndexCrowding] = update(set, crowding, indexCrowding, index)
	diferences = sum(abs(set - repmat(set(:,index), 1, size(set,2))));
	diferences(index) = Inf;

	newIndexCrowding = indexCrowding;
	newIndexCrowding(diferences < crowding) = index;
	newCrowding = min(crowding, diferences);
end

function [pos dist] = getClosest(set, index)
	diferences = sum(abs(set - repmat(set(:,index), 1, size(set,2))));
	diferences(index) = Inf;
	[dist pos] = min(diferences);
end

function dist = hammingDist(s1, s2)
	dist = sum(abs(s1 - s2));
end

function dist = distance(s1,s2)
	sub = s1 - s2;
	sub = abs(sub);
	dist = max(sub);
end

function x = makeSymmetric(point, minBound, maxBound)
	x = point;

	while sum (x < minBound) > 0 || sum(x > maxBound) > 0
		x = x + ((x < minBound) .* (2 * minBound - 2 * x));
		x = x + ((x > maxBound) .* (2 * maxBound - 2 * x));
	end
end


function x= real2binary(num, minbound, maxbound, lengthBinary)

	maxValue = 2^lengthBinary - 1;
	inInt = (num - minbound) * maxValue / (maxbound - minbound);
	aux = (lengthBinary-1):-1:0;
	aux = 2 .^ aux;
	x=mod(floor(inInt ./ aux), 2);
end

function x= binary2real(num, minbound, maxbound)

	aux = (length(num)-1):-1:0;
	aux = 2 .^ aux;
	aux = sum(aux .* num);
	x = aux / (2^length(num) - 1) * (maxbound - minbound) + minbound;
end

function x=gray2binary(num)
	last = 0;
	x=[];
	
	for i=num
		value = mod(i + last, 2);
		x = [x value];
		last = value;
	end
end

function x=binary2gray(num)

	offset = [0 num(1:(length(num) - 1))];
	x = mod(num + offset, 2);
end

function x=real2gray(num, minbound, maxbound, lengthBinary)
	aux=real2binary(num, minbound, maxbound, lengthBinary);
	x = binary2gray(aux);
end

function x=gray2real(num, minbound, maxbound)
	aux = gray2binary(num);
	x = binary2real(aux, minbound, maxbound);
end

function x=arrayReal2gray(s, minbound, maxbound, lengthBinary)
	x = [];
	numVars = length(x);

	for i=1:numVars
		x = [x real2gray(s(i), minbound, maxbound, lengthBinary)];
end

function x=blxAlpha(alpha, p1, p2, minbound, maxbound)
	cmax = max(p1, p2);
	cmin = min(p1, p2);
	distance = cmax - cmin;
	cmin = cmin - distance * alpha;
	cmax = cmax + distance * alpha;
	x = rand(length(p1), 1);
	x = x .* (cmax - cmin) + cmin;
	x = makeSymmetric(x, minbound, maxbound);
end

function [pop fvalues]=initiatePopulation(seed, minsigma, maxsigma, popSize, minbound, maxbound, FUN)

	pop = randn(length(seed), popSize) * (maxsigma - minsigma);
	pop = pop + sign(pop) * minsigma;
	fvalues = [];

	for i=1:popSize % para cada columna (individudo) centrar en seed
		pop(:,i) = pop(:,i) + seed;
		pop(:,i) = makeSymmetric(pop(:,i), minbound, maxbound);
		fvalues = [fvalues feval(FUN, pop(:,i))];
	end
end

function [best fvalues]=getBests(set, fset, popSize)
	[aux, numIndividuals] = size(set);
	numSelected = 0;
	fvalues = [];

	while numSelected < popSize && numIndividuals > 0
		[aux, pos] = min(fset);
		numSelected++;
		best(:,numSelected) = set(:, pos);
		fvalues = [fvalues fset(pos)];
		
		set=[set(:,1:(pos-1)) set(:,(pos+1):numIndividuals)];
		fset = [fset(1:(pos-1)) fset((pos+1):numIndividuals)];
		numIndividuals--;
	end
end

function [best fvalues] = cataclysmicMut(set, fset, seed, minsigma, maxsigma, popSize, minbound, maxbound, FUN)
	[best fvalues] = getBests(set, fset, 1);
	best(:,2:popSize) = randn(length(seed), popSize - 1) * (maxsigma - minsigma);
	best(:,2:popSize) = best(:,2:popSize) + sign(best(:,2:popSize)) * minsigma;

	for i=2:popSize
		best(:,i) = best(:,i) + seed;
		best(:,i) = makeSymmetric(best(:,i), minbound, maxbound);
		fvalues = [fvalues feval(FUN, best(:,i))];
	end
end

function [offspring fvalues] = doGeneration(set, threshold, alpha, seed, minbound, maxbound, FUN)
	[aux, numIndividuals] = size(set);
	pairs = randperm(numIndividuals);
	offspring = [];
	fvalues = [];

	for i=1:2:(numIndividuals-1)
		p1 = set(:,pairs(i));
		p2 = set(:,pairs(i+1));
		binP1 = arrayReal2gray(p1, minbound, maxbound, 20);
		binP2 = arrayReal2gray(p2, minbound, maxbound, 20);
		dist = hammingDist(binP1, binP2);

		if (dist > threshold)
			coffspring = blxAlpha(alpha, p1, p2, minbound, maxbound);
			coffspring = makeSymmetric(coffspring, minbound, maxbound);
			offspring = [offspring coffspring];
			fvalues = [fvalues feval(FUN, coffspring)];
		end
	end

	last = floor(rand() * numIndividuals) + 1;
	plast = set(:,last);
	binPlast = arrayReal2gray(plast, minbound, maxbound, 20);
	binSeed = arrayReal2gray(seed, minbound, maxbound, 20);
	dist = hammingDist(binPlast, binSeed);

	if (dist > threshold)
		coffspring = blxAlpha(alpha, plast, seed, minbound, maxbound);
		coffspring = makeSymmetric(coffspring, minbound, maxbound);
		offspring = [offspring coffspring];
		fvalues = [fvalues feval(FUN, coffspring)];
	end
end

function [best fvalue numEvals] = runMicroCHC(seed, popSize, alpha, minsigma, maxsigma, minbound, maxbound, nbits, maxEvals, FUN)
	[pop fvalues]=initiatePopulation(seed, minsigma, maxsigma, popSize, minbound, maxbound, FUN);
	numEvals = popSize;
	threshold = nbits * length(seed) / 4;

	while numEvals < maxEvals
		[offspring offfvalues] = doGeneration(pop, threshold, alpha, seed, minbound, maxbound, FUN);
		[aux numoffspring] = size(offspring);
		numEvals += numoffspring;

		if (numoffspring == 0)
			threshold--;
		
			if threshold == 1
				[newPop newFvalues] = cataclysmicMut(pop, fvalues, seed, minsigma, maxsigma, popSize, minbound, maxbound, FUN);
				meansigma = ((maxsigma + minsigma) / 2) / (maxbound - minbound); %se divide por (maxbound - minbound) para que esté entre 0 y 1
				threshold = nbits * length(seed) * meansigma * (1 - meansigma);
				pop = newPop;
				fvalues = newFvalues;
				numEvals += (popSize - 1);
			end
		else
			tempPop = [pop offspring];
			tempFvalues = [fvalues offfvalues];
			[pop fvalues] = getBests(tempPop, tempFvalues, popSize);
		end
	end

	[best fvalue] = getBests(pop, fvalues, 1);
end

function offspring = pseudoPBXalpha(currentS, mate, alfa)
	dimension = length(currentS);

	dist = mate - currentS;
	low = zeros(dimension, 1);
	high = zeros(dimension, 1);
	low = low + ((dist < 0) .* (dist * alfa + currentS));
	low = low + ((dist >= 0) .* (currentS - dist * alfa));
	high = high + ((dist < 0) .* (currentS - dist * alfa));
	high = high + ((dist >= 0) .* (dist * alfa + currentS));
	offspring = rand(dimension, 1) .* (high - low) + low;
end

function [newpob newfPob newCrowding newIndexCrowding] = insert2(pob, fPob, crowding, indexCrowding, currentS, fcs, maxSize)

	newpob = [pob currentS];
	newfPob = [fPob fcs];
	numElements = size(newpob,2);
	[newCrowding newIndexCrowding] = update(newpob, [crowding 0], [indexCrowding 0], numElements);

	[auxPos auxDist] = getClosest(newpob, numElements);
	newCrowding(numElements) = auxDist;
	newIndexCrowding(numElements) = auxPos;

	if (numElements > maxSize)
		auxDist = min(newCrowding);
		posibles = find(newCrowding == auxDist);
		[aux aEliminar] = max(newfPob(posibles));
		aEliminar = posibles(aEliminar);
		
		newpob = [newpob(:, 1:(aEliminar-1)) newpob(:, (aEliminar+1):numElements)];
		newfPob = [newfPob(1:(aEliminar-1)) newfPob((aEliminar+1):numElements)];
		newCrowding = [newCrowding(1:(aEliminar-1)) newCrowding((aEliminar+1):numElements)];
		newIndexCrowding = [newIndexCrowding(1:(aEliminar-1)) newIndexCrowding((aEliminar+1):numElements)];
		numElements--;

		updating = find(newIndexCrowding == aEliminar);

		for i=updating
			[auxPos auxDist] = getClosest(newpob, i);
			newCrowding(i) = auxDist;
			newIndexCrowding(i) = auxPos;
		end
	end
end

function [pob fitness crowding indexCrowding] = initiatePob(numIndividuals, dimension, minbound, maxbound, FUN)
	pob = rand(dimension, numIndividuals) * (maxbound - minbound) + minbound;
	fitness = [];
	crowding = [];
	indexCrowding = [];

	for i = 1:numIndividuals
		fitness = [fitness feval(FUN, pob(:,i))];
	end

	for i=1:numIndividuals
		[auxPos auxDist] = getClosest(pob, i);
		crowding = [crowding auxDist];
		indexCrowding = [indexCrowding auxPos];
	end
end

function [mate fmate minDist] = getBetterNearest(set, fPob, currentS, fcs, thresholdDist)

	betters = find(fPob < fcs);
	setBetters = set(:,betters);
	fSetBetters = fPob(betters);
	numElements = length(betters);
	fmate = [];
	minDist = 0.;
	mate = [];

	if numElements > 0

		diferences = sum(abs(setBetters - repmat(currentS, 1, size(setBetters,2))));
		auxDiffs = diferences;
		auxDiffs(diferences < thresholdDist) = max(diferences);
		[minDist pos] = min(auxDiffs);
		mate = setBetters(:,pos);
		fmate = fSetBetters(pos);
		minDist = diferences(pos);
	end
end



function [newSolution newfcs countEvals newPob newFitness newCrowding newIndexCrowding] = optimize(currentS, fcs, pob, fPob, crowding, indexCrowding, alfa, maxSize, thresholdDist, FUN)

	countEvals = 0;
	iteracionesSinMejora = 0;
	newSolution = currentS;
	newfcs = fcs;
	fBest = fcs;
	xBest = currentS;

	[mate fmate minDist] = getBetterNearest(pob, fPob, newSolution, newfcs, thresholdDist);

	while iteracionesSinMejora < 100

		if minDist > thresholdDist
			offspring = pseudoPBXalpha(newSolution, mate, alfa);
		else
  			offspring = newSolution + randn(length(newSolution), 1) * alfa * thresholdDist;
		end

		fOffspring = feval(FUN, offspring);
		countEvals += 1;

		if (fOffspring < fBest)
			xBest = offspring;
			fBest = fOffspring;
			iteracionesSinMejora = 0;
			fcs = (fBest + fcs) / 2;
		else
			iteracionesSinMejora++;
		end

  		if (fOffspring < fcs)

			[newpob newfPob crowding indexCrowding] = insert2(pob, fPob, crowding, indexCrowding, offspring, fOffspring, maxSize);
			pob = newpob;
			fPob = newfPob;

			newSolution = offspring;
			newfcs = fOffspring;
			[mate fmate minDist] = getBetterNearest(pob, fPob, newSolution, newfcs, thresholdDist);
		end

	end

	newSolution = xBest;
	newfcs = fBest;
	newPob = pob;
	newFitness = fPob;
	newCrowding = crowding;
	newIndexCrowding = indexCrowding;
end
