clear; clc; close all;

fitness = @fRealRosenbrock; ftarget = 1e-8;
% fitness = @(x) fRealRidgeSharp(x, 1e-6); ftarget = -inf;
% fitness = @(x) sum(x.^2,1); ftarget = 1e-8;
maxiter = 10000;

D = 20;
k = sqrt(D);
if D <= 4,
    k = k * (0.3 + 0.25*D);
else
    k = k * (1.45 + 0.013*D);
end
N = ceil((D^1.37) * 10^1.06);
tau = 0.3;

fevals = 0;
mu = [-3 ones(1,D-1)]'; sig = 0.1*ones(1,D)'; R = eye(D);
baseSampleFunc = @(D,N) randCauchyNormalized(D, N, tau);
x = sampleAndTransform( baseSampleFunc, N, mu, sig, R);
f = fitness(x);
fmin = min(f);
fevals = fevals + numel(f);
[isel,idis] = selTruncation(f, tau);

if D == 2,
    fig = figure; hold on;
    plotShape(fig, mu, sig, R, 'k--');
    axis equal;
end

% Model
i = 0;
while i < maxiter && ...
        fmin > ftarget && ...
        max(sig) > 1e-6,
    
%         max(f)-min(f) > 1e-14 && ...

    i = i+1;
%     avebest = mean(x(:, isel(1:Nsel)), 2);
    avebest = mean(x(:, isel), 2);
    mu = avebest;
%     shapemat = shapematrix( x(:, idis(1:Ndis)), avebest );
    shapemat = shapematrix( x(:, isel), avebest );
    if ~all(all(isreal(shapemat))),
        keyboard;
    end

    [Rnew,signew] = estimateShape(shapemat);
    if ~all(all(isreal(Rnew))), keyboard; end
    if ~all(all(isreal(signew))), keyboard; end
    
    signew = k * signew ;
    signew(signew < 1e-7) = 1e-7;
    
    aR = 0.; R = aR*R + (1-aR)*Rnew;
    asig = 0.; sig = asig*sig + (1-asig)*signew;
    
    if D==2,
        plotShape(fig, mu, sig, R, 'k-' );
    end

    x = sampleAndTransform( baseSampleFunc, N, mu, sig, R);
    if ~all(all(isreal(x))), keyboard; end
    f = fitness(x);
    fevals = fevals + numel(f);
    fmin = min(f);
    [isel, idis] = selTruncation( f, tau );
    
    fprintf('Fevals: %d   fmin: %.3e   max(f)-min(f): %.3e   TolX: %.3e\n', ...
        fevals, ...
        fmin, ...
        max(f)-min(f), ...
        max(sig) );
%     pause;
end

if D==2,
    % Plot the fitness
    ax = axis;
    xg = ax(1):0.05:ax(2);
    yg = ax(3):0.05:ax(4);
    [xx,yy] = meshgrid(xg,yg);
    fg = log10(fitness([xx(:) yy(:)]'));
    fg = reshape(fg, size(xx));
    [foo,ch] = contour(xg,yg,fg);
end

% print -depsc2 picXbestXworst
