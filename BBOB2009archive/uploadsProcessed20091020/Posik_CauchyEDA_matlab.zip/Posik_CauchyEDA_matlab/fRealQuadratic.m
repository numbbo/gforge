function f = fRealQuadratic(x, varargin)
%
% FREALQUADRATIC Evaluation function for 2D real vector, sum of squares of
% vector elements.
%

f = sum(x.^2,2);
