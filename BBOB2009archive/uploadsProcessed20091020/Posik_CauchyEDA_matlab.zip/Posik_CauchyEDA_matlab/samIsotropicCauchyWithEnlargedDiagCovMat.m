function pop = samIsotropicCauchyWithEnlargedDiagCovMat(model, par)
%
% samIsotropicCauchyWithEnlargedDiagCovMat Samples an isotropic
% distribution - the norms of the sampled vectors have standard Cauchy
% distribution. Individual axes are then scaled by standard
% deviations and multiplied by a constant k. 
%

if ~exist('par','var') | isempty(par), par = struct; end
if iscell(par), par = struct(par{:}); end
if ~isfield(par,'verbose'), par.verbose = 1; end

if ~isfield(par.sam,'nOffspring'), par.sam.nOffspring = par.popsize; end
if ~isfield(par.sam,'k'), 
    par.sam.k = 1;
    warning('HOAtbx:UsingDefaultValue','Using default value of k=1.');
end

nOffspring = par.sam.nOffspring;
k = par.sam.k;
dim = length(model.mu);

if par.verbose, 
    fprintf('Sampling isotropic Cauchy: #Offspring = %d   dim = %d\n', nOffspring, dim);
end

mu = model.mu(:)';
sigma = k * model.sigma(:)';

% Sample data with Cauchy distribution of norms
pop = cauchypolarrnd(dim,nOffspring)';
% Standardize in such a way that the tau selected lowest norms lie at most
% at the distance of 1 from the origin
if isfield(par.sam,'standTo1') && par.sam.standTo1 == 1, 
    if ~isfield(par.sel,'tau'), error('HOAtbx:MissingArgument','Need the par.sel.tau parameter.'); end
    xcq = sqrt(cauchyinv((1+par.sel.tau)/2, 0, 1));    
    pop = 1/xcq * pop;
end
% Move the population to mu and scale the axes by sigmas
pop = mu(ones(nOffspring,1),:) + sigma(ones(nOffspring,1),:) .* pop;