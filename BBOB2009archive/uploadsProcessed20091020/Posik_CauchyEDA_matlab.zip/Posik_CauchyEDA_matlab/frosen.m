function f = frosen(x)
    x1 = x(1:end-1,:);
    x2 = x(2:end,:);
    f = sum( 100*( x1.^2 - x2 ).^2 + (x1-1).^2, 1 );
end