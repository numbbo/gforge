function [xmin, fmin, fevals, exitflag] = bbobfminbndLineSearch(...
    FUN, x0, ftarget, opts)

[D,N] = size(x0);

xmin = x0;
fmin = inf;
fevals = 0;

if nargin < 4 || isempty(opts), opts = optimset(); end
defopts = struct(...
    'MaxFunEvals', 1e2*D, ... %min(3e3*D, opts.MaxFunEvals), ...
    'TolX', 1e-10, ...
    'Display', 'iter' ...
    );
opts = optionsOrDefaults(opts, defopts);
% Prepare options for fminbnd
fminopts = opts;
fminopts.Display = 'off';

verbosity = 0;
if strcmp(opts.Display, 'final'), verbosity = 1; end
if strcmp(opts.Display, 'iter'), verbosity = 2; end

% Start the main cycle
xminchange = inf;
while true,

    if (fmin <= ftarget), exitflag = 'Ftarget'; break; end
    if (fevals >= opts.MaxFunEvals), exitflag = 'MaxFunEvals'; break; end
    if (xminchange < opts.TolX), exitflag = 'TolX'; break; end

    xminold = xmin;
    % Create the order of dimensions randomly
    dims = randperm(D);
    for idim = 1:D,

        % Prepare options for fminbnd
        fminopts.MaxFunEvals = opts.MaxFunEvals - fevals;

        [xinew,fnew,exitflag,output] = fminbnd(@proxyFUN,-6,6,fminopts);
        xnew = xmin;
        xnew(dims(idim)) = xinew;
        fevals = fevals + output.funcCount;

        if verbosity >= 2,
            fprintf('Fevals: %d   idim: %d   dim: %d   xi: %.1e -> %.1e   fmin-fopt: %2e\n', ...
                fevals, ...
                idim, ...
                dims(idim), ...
                xmin(dims(idim)), xnew(dims(idim)), ...
                fnew-ftarget+1e-8);
        end

        if fnew < fmin,
            xmin = xnew;
            fmin = fnew;
        end

        if (fmin < ftarget) || (fevals >= opts.MaxFunEvals), break; end
    end
    
    xminchange = sqrt( sum( (xmin-xminold).^2 ) );

end

if verbosity >= 1,
    fprintf('Finished. Fevals: %d   Fmin: %.3f\n', fevals, fmin);
end

%%
    function f = proxyFUN(xi)
        myx = xmin;
        myx(dims(idim)) = xi;
        f = feval(FUN, myx);
    end

end
