function [x, ilaunch] = bbobRestfminbndLineSearch(FUN, ...
    DIM, ftarget, outermaxfunevals, innermaxfunevals, varargin)

% multistart such that ftarget is reached with reasonable prob.
for ilaunch = 1:100  % relaunch optimizer up to 100 times

    % Initialize
    x0 = -5 + 10*rand(DIM, 1); % Random start solution

    opts.MaxFunEvals = min( outermaxfunevals-fgeneric('evaluations'), innermaxfunevals );
    opts.Display = 'off';

    % try fminbndLineSearch
    x = bbobfminbndLineSearch(FUN, x0, ftarget, opts, varargin{:});

    if (fgeneric('fbest') < ftarget) || (fgeneric('evaluations') >= outermaxfunevals),
        break;
    end
end
