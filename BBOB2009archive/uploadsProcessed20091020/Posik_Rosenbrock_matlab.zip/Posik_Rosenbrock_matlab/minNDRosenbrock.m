function [x,fval,exitflag,output,hist] = minNDRosenbrock(func, x, o, varargin)
%
% MINNDRosenbrock Function minimization using Rosenbrock's method
%
% Package: HOAtbx
%
% Description:
%   [x,fval,exitflag,output] = MinNDRosenbrock(func, x, options, varargin)
%

interactive = 0;
fevals = 0;
hist.nIters = [];
hist.nEvals = [];
hist.fval = [];

%% Parameter check and initialization
if ~exist('func','var') | isempty(func), error('Function not set'); end
if ~exist('x','var')    | isempty(x), error('Starting point not given.'); end
if ~exist('o','var')    | isempty(o), o = struct; end
if iscell(o), o = struct(o{:}); end
if ~isfield(o,'TolX'), o.TolX = 1e-10; end
if ~isfield(o,'TolFun'), o.TolFun = 1e-8; end
if ~isfield(o,'MaxFunEvals'), o.MaxFunEvals = 5000*length(x(:)); end
if ~isfield(o,'MaxIter'), o.MaxIter = inf; end
if ~isfield(o,'StopFitness'), o.StopFitness = 1e-8; end

n = numel(x);

% Convert to inline function as needed.
func = fcnchk(func,length(varargin));

%% Initialize variables
bigbnd = inf;
alpha = 2;
beta = 0.5;
xi = eye(n);
A = zeros(n,n);
xk = x;
d = 0.1 * ones(1,n);
lambda = zeros(1,n);
yfirstfirst = feval(func, x, varargin{:});
fevals = fevals + 1;

if interactive,
    figure; hold on;
end

%% Start the main loop
restart = 1;
iter = 1;
while true,
    
    ybest = yfirstfirst;
    yfirst = inf;
    
    if (ybest <= o.StopFitness), exitflag = 'StopFitness'; break; end
    if (iter >= o.MaxIter), exitflag = 'MaxIter'; break; end
    if (fevals >= o.MaxFunEvals), exitflag = 'MaxFunEvals'; break; end
    if (max(abs(d)) < o.TolX), exitflag = 'TolX'; break; end
    
    while (ybest < yfirst),
        
        yfirst = ybest;
        
        % Try changing the point in n directions
        for i = 1:n,
            xcurrent = xk + d(i)*xi(i,:);
            
            ycurrent = feval(func, xcurrent, varargin{:});
            fevals = fevals + 1;
            
            if (ycurrent<ybest),
                % success
                ybest = ycurrent;
                lambda(i) = lambda(i) + d(i);
                d(i) = alpha * d(i);
                xk = xcurrent;
            else
                % failure
                d(i) = -beta * d(i);
            end
        end
    end
    
    if interactive,
        for i = 1:n,
            plot([xk(1) xk(1)+d(1)*xi(i,1)], [ xk(2) xk(2)+d(2)*xi(i,2)], 'k-' );
        end
        drawnow;
    end
    if interactive > 1, pause; end
    
    mini = min([abs(d) bigbnd]);
    restart = mini>eps;
    
    if ybest < o.StopFitness,
        restart = 0;
    end
    
    % Compute new orthogonal basis xi using Palmer's method
    if (ybest < yfirstfirst),
        
        mini = min([abs(xk-x) bigbnd]);
        restart = restart | (mini > eps);
        
        if (restart),
            A = repmat(lambda(:),1,n) .* xi;
            ind = n:-1:1;
            A(ind,:) = cumsum(A(ind,:),1);
            
            t(ind) = cumsum(lambda(ind).^2);
            
            for i = n:-1:2,
                div = sqrt(t(i-1)*t(i));
                if (div ~=0),
                    xi(i,:) = (lambda(i-1)*A(i,:) - xi(i-1,:)*t(i)) / div;
                end
            end
            div = sqrt(t(1));
            xi(1,:) = A(1,:) / div;
            
            x = xk;
            lambda = zeros(1,n);
            d = 0.1 * ones(1,n);
            yfirstfirst = ybest;
        end
    end
    
    hist.nIters(end+1) = iter;
    hist.nEvals(end+1) = fevals;
    hist.fval(end+1) = ybest;
    
    iter = iter + 1;
end

output.iterations = iter;
output.funcCount = fevals;
output.algorithm = 'Rosenbrock''s direct search';

fval = ybest;
x = xk;

end