function [x, ilaunch] = bbobRestRosenbrockLS(FUN, ...
    DIM, ftarget, outermaxfunevals, innermaxfunevals, varargin)

options = struct('MaxFunEvals', min(1e8*DIM, outermaxfunevals), ...
    'MaxIter', inf, ...
    'Tolfun', 1e-11, ...
    'TolX', 1e-9, ...
    'StopFitness', ftarget, ...
    'Display', 'off' ...
    );

for ilaunch = 1:100; % relaunch optimizer up to 100 times
    % set initial conditions
    ropts = options;
    ropts.MaxFunEvals = min( innermaxfunevals, outermaxfunevals - feval(FUN,'evaluations'));
    ropts.dInit = 0.1;

    xstart = -5 + 10 * rand(1,DIM); % random start solution

    % try the Rosenbrock's algorithm
    x = minNDRosenbrockMod(FUN, xstart, ropts);
    if feval(FUN, 'fbest') < ftarget || feval(FUN, 'evaluations') >= options.MaxFunEvals,
        break;
    end
end
