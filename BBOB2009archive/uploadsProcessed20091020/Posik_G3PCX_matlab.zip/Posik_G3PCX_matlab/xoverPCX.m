function [xnew, Dmin] = xoverPCX(x, o)

    % Parameter check and initialization
    if ~exist('x','var')    | isempty(x), error('Parents not given.'); end
    if ~exist('o','var')    | isempty(o), o = struct; end
    if iscell(o), o = struct(o{:}); end
    if ~isfield(o,'sigmaParent'), o.sigmaParent = 0.1; end
    if ~isfield(o,'sigmaOther'), o.sigmaOther = 0.1; end

    sigmaParent = o.sigmaParent;
    sigmaOther = o.sigmaOther;

    [D,mu] = size(x);

    % Compute mean of the parents
    g = mean(x,2);
    % Compute direction vectors
    d = x - repmat(g,1,mu);
    % Compute the distances
    sizes = sqrt(sum(d.^2,1));
    Dmin = min(sizes);
%     if Dmin <= 1e-14, keyboard; end

    % Choose parent
    p = 1; %ceil(mu * rand);
    % Select the main parental vector and calculate its size
    dp = d(:,p);
    Dp = sizes(p);
    % Compute distances of the other parents to line g-xp
    % Project all parents to line dp
    dpr = dp * dp' * d / (Dp^2);
    % Subtract projections
    dsub = d - dpr;
    % Compute average length of dsub
    D_not = sum( sqrt(sum( dsub.^2, 1 )) ) / (mu-1);

    % Construct offspring
    xnew = sigmaOther * D_not * randn(D,1);
    % Project it on dp
    xnewpr = dp * dp' * xnew / (Dp^2);
    % Subtract the projection
    xnew = xnew - xnewpr;
    % Add random component in the direction dp
    xnew = xnew + sigmaParent * randn * dp;
    % Center it around parent
    xnew = xnew + x(:,p);
    
%             w1 = sqrt(2*log(sigma1)) * randn;
%             xnew = xnew + x(:,p) + (exp(w1)-1)*d(:,p);
%             w1 = -ln2/2 + sqrt(ln2) * randn;
%             xnew = xnew + x(:,p) + (exp(w1)-1)*d(:,p);
end

