clc; clear;
% minimizes FUN in DIM dimensions by multistarts of fminsearch.
% ftarget and maxfunevals are additional external termination conditions.
% fminsearch was modified to take as input a delta_i to generate
% the first simplex.
% set options, make sure we always terminate

FUN = @(x) sum( (x-2).^2, 1 ); % Sphere
% FUN = @(x) sum( diag(1:size(x,1))*((x-2).^2), 1 );  % Ellipsoid
% FUN = @(x) sum( cumsum((x-2).^2,1), 1 ); % Schwefel
FUN = @frosen;
DIM = 20;
popsize = 5*DIM+90; %5*DIM;
maxfunevals = 1e5*DIM;
ftarget = 1e-8;

fevals = 0;
options = optimset(...
    'MaxFunEvals', maxfunevals, ...
    'MaxIter', 2e3*DIM, ...
    'TolX', 1e-15, ...
    'Display', 'iter');
options.ftarget = 1e-8;

% multistart such that ftarget is reached with reasonable prob.
for ilaunch = 1:1  % relaunch optimizer up to 100 times

    par = -5 + 10*rand(DIM, popsize); % Random start solution

    % try minG3mPCX
    [x fmin myfevals] = minG3PCX(FUN, par, options, @isOutside)
    fevals = fevals + myfevals;

    if fmin < ftarget %|| fevals >= maxfunevals
        break;
    end
    % if useful, modify more options here for next launch
end