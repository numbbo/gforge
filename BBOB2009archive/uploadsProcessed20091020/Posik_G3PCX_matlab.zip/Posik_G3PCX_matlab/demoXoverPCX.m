lambda = 1000;

% x = [4 3; 1 0; -5 -3]';
x = [1 0; 0 1; 3 1]';
offs = zeros(2,lambda);

g = mean(x,2);

for i = 1:lambda,
    offs(:,i) = xoverPCX(x);
end

figure(1);
plot(offs(1,:),offs(2,:),'k.'); hold on;
for i = 1:size(x,2),
    plot([g(1) x(1,i)], [g(2) x(2,i)], 'k-');
end
plot(x(1,:),x(2,:),'mo','MarkerSize',10,'MarkerFaceColor','m');
plot(g(1), g(2), 'ko', 'MarkerFaceColor', 'w');
axis equal;
% axis([-22 22 -20 20]);
set(gca,'Fontsize',16);
% print -depsc2 demoMPCX3p

%%
x = [0 0; 5 0; 1 2; 4 4]';

offs = zeros(2,lambda);

for i = 1:lambda,
    offs(:,i) = xoverPCX(x);
end

figure(2);
plot(offs(1,:),offs(2,:),'k.'); hold on;
plot(x(1,:),x(2,:),'mo','MarkerSize',10,'MarkerFaceColor','m');
axis equal;
axis([-22 22 -20 20]);
set(gca,'Fontsize',16);
% print -depsc2 demoMPCX4p