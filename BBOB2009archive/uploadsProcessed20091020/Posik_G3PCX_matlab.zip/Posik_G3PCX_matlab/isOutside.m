function out = isOutside(x)
% Checks if points are outside the (-5,5) interval in any dim.
    out = any( x > 6 | x < -6 , 1);
end