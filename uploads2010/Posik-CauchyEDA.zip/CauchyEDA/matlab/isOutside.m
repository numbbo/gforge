function out = isOutside(x)
% Checks if points are outside the (-5,5) interval in any dim.
    out = any( x > 8 | x < -8 , 1);
end