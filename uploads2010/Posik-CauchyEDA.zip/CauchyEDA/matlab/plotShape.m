function plotShape(fig, mu, sig, R, pat);

    al = (0:(2*pi/100):2*pi)';
    x = [cos(al) sin(al)]';
    
    N = size(x,2);
    x = diag(sig) * x;
    x = R * x;
    x = x + repmat(mu,1,N);
    
    figure(fig);
    washold = ishold;
    hold on;
    plot(x(1,:),x(2,:),pat,'Linewidth',1.5);
    if ~washold, hold off; end
end