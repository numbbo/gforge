function m = shapematrix(x, center)

    [D,N] = size(x);
    xc = bsxfun(@minus, x, center);
    m = (xc*xc') / (N-1);
end