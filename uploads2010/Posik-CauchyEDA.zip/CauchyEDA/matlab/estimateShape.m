function [R,sig] = estimateShape(m)

    [R,sig] = eig(m);
    sig = diag(sig);
    sig = sqrt(sig);
    
    R = real(R);
    sig = real(sig);

end