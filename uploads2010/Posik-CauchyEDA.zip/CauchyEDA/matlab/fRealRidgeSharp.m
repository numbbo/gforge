function f = fRealRidgeSharp(x, wlin, varargin)
%
% FREALRIDGESHARP Sharp ridge evaluation function for real vectors.
%

f = -wlin*x(1,:) + sqrt(sum(x(2:end,:).^2,1));
