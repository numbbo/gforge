function [x, ilaunch] = bbobRestCauchyEDA(FUN, ...
    DIM, ftarget, outermaxfunevals, innermaxfunevals, varargin)

    fevals = 0;
    % multistart such that ftarget is reached with reasonable prob.
    for ilaunch = 1:100  % relaunch optimizer up to 100 times

        opts.MaxFunEvals = min( outermaxfunevals-fevals, innermaxfunevals );
        x0 = -5 + 10*rand( DIM, 1 ); % Random start solution 
        
        [x fmin myfevals exitflag output] = bbobMinCauchyEDA(FUN, x0, ftarget, opts, varargin{:});
        fevals = fevals + myfevals;

        if (fmin < ftarget) || (fevals >= outermaxfunevals), break; end
    end
end