function demoSTEP

    clc;
    
    maxiter = 20;
    printfigures = [1:8 maxiter];

    fun = @(x) 2*sin(0.5*pi*(x-0.2)) + 0.0008*(x-0.5).^5 - x;
    ep = .1;
    % init interval
    x = [-6 6]';
    % evaluate boundary points
    x(1,2) = fun(x(1,1));
    x(2,2) = fun(x(2,1));
    fmin = min(x(:,2));
    
    ints = [1 2];
    [ints(3),ints(4),ints(5)] = difficulty(x(1,:), x(2,:));
    
    %% Start loop
    for iter = 1:maxiter,
        % Find the most promissing interval
        [foo ibest] = min(ints(:,3));
        
        x1 = x(ints(ibest,1),1);
        x2 = x(ints(ibest,2),1);
        xnext = (x1+x2)/2;
    
        plotFunc;

        xnew = xnext;
        fnew = fun(xnew);

        x(end+1,:) = [xnew fnew];
        inew = size(x,1);
        ints(end+1,1:2) = ints(ibest,1:2);
        ints(ibest,2) = inew;
        ints(end,1) = inew;
        if fnew < fmin, 
            fmin = fnew;
            for iint = 1:size(ints,1),
                [ints(iint,3),ints(iint,4),ints(iint,5)] = ...
                    difficulty(x(ints(iint,1),:), x(ints(iint,2),:));
            end
        else
            [ints(ibest,3),ints(ibest,4),ints(ibest,5)] = ...
                difficulty(x(ints(ibest,1),:), x(ints(ibest,2),:));
            [ints(end,3),ints(end,4),ints(end,5)] = ...
                difficulty(x(ints(end,1),:), x(ints(end,2),:));
        end
        if ismember(iter, printfigures),
            fname = sprintf('demoSTEP%02d',iter);
            print('-depsc2',fname);
        end
        pause;
    end
    
    
    

    function plotFunc
        xx = x(1,1):0.05:x(2,1);
        ff = fun(xx);
        plot(xx,ff,'b-','Linewidth',1.5); hold on;
        ax = axis;
        ax(1:2) = [-6.05 6.05];
        ax(3:4) = [-7 7]; axis(ax);
        plot(ax(1:2), [fmin fmin], 'k--');
        plot(ax(1:2), [fmin-ep fmin-ep], 'k-');
        plot(x(:,1), x(:,2), 'ko', 'MarkerFaceColor','k');
        [foo isort] = sort(x(ints(:,1),1));
        for i = 1:size(ints,1),
            a = ints(i,3);
            b = ints(i,4);
            c = ints(i,5);
            xl = x(ints(i,1),1);
            fl = x(ints(i,1),2);
            xu = x(ints(i,2),1);
            xx = xl:0.05:xu;
            ff = a*(xx-xl).^2 + b*(xx-xl) + c;
            plot(xx,ff,'r-','Linewidth',1);
            if iter < maxiter,
                ind = find(isort == i);
                offset = (mod(ind-1,3)+1) * 0.5;
                text((xl+xu)/2, ax(4)-offset, sprintf('%.1f', ints(i,3)), 'Fontsize',16);
            end
        end
        
        plot([xnext xnext], ax(3:4), 'k-');
        
        if exist('xnew') && ~isempty(xnew),
            plot(xnew, fnew, 'ro', 'MarkerFaceColor','r');
        end
        title(sprintf('Iteration: %d', iter), 'Fontsize',16);
        set(gca,'FontSize',16);
        
        hold off;
    end

    function [a,b,c] = difficulty(x1, x2)
        % x1 and x2 are 1x2 vectors of data points given by their x-values
        % and fitnesses.
        % The function interpolates the points x1 and x2 by a parabola. The
        % third defining criterion of the parabola is that it must at least
        % touch the fitness value fmin-eps.
        % Function returns 2 * the second derivative of the parabola
        % ax^2+bx+c, i.e. the coefficient a.

        myx = x2(1) - x1(1);
        myy = x2(2) - x1(2);
        myf = fmin - ep - x1(2);

        a = (myy - 2*myf + 2*sqrt(myf*(myf - myy))) / myx^2;
        if nargout > 1, b = myy/myx - a*myx; end
        if nargout > 2, c = x1(2); end
    end
end