function [xmin, fmin, fevals, exitflag, output] = bbobMinSTEPLineSearch(...
    FUN, x0, ftarget, o)

D = size(x0,1);

xmin = x0;
fmin = inf;
fevals = 0;

if nargin < 4 || isempty(o), o = optimset(); end
defopts = struct(...
    'MaxFunEvals', 200*D, ... %min(3e3*D, opts.MaxFunEvals), ...
    'TolX', 1e-10, ...
    'Display', 'iter' ...
    );
opts = optionsOrDefaults(o, defopts);

% Prepare options for STEP
stopts = opts;
stopts.MaxFunEvals = min(400, round(opts.MaxFunEvals / D));
stopts.Ftarget = ftarget;

verbosity = 0;
if strcmp(opts.Display, 'final'), verbosity = 1; end
if strcmp(opts.Display, 'iter'), verbosity = 2; end

% Start the main cycle
while true,

    % Test termination conditions
    if fmin < ftarget, exitflag = 'Ftagret'; break; end
    if fevals >= opts.MaxFunEvals, exitflag = 'MaxFunEvals'; break; end

    xminchanged = false;
    % Create the order of dimensions randomly
    dims = randperm(D);
    for idim = 1:D,

        % Prepare options for min1DSTEP
        dopts = stopts;
        dopts.MaxFunEvals = min(opts.MaxFunEvals - fevals, stopts.MaxFunEvals);
        
        prfun = @proxyFUN;
        [xinew, fnew, fevals1, exitflag, xp, ints] = ...
            min1DSTEP(prfun, [-6 6], dopts);
        xnew = xmin;
        xnew(dims(idim)) = xinew;
        fevals = fevals + fevals1;

        if verbosity >= 2,
            fprintf('Fevals: %d   idim: %d   dim: %d   xi: %.1e -> %.1e   fmin-fopt: %.2e   Why: %s\n', ...
                fevals, ...
                idim, ...
                dims(idim), ...
                xmin(dims(idim)), xnew(dims(idim)), ...
                fnew - ftarget + 1e-8, ...
                exitflag);
        end

        if fnew < fmin,
            xminchanged = true;
            xmin = xnew;
            fmin = fnew;
        end

    end

    if (fmin < ftarget) || ...
            (fevals >= opts.MaxFunEvals) || ...
            (~xminchanged),
        break;
    end

end

output.Fevals = fevals;
output.Fbsf = fmin;

if verbosity >= 1,
    fprintf('Finished. Fevals: %d   Fmin: %.3e\n', fevals, fmin-ftarget+1e-8);
end

%%
    function f = proxyFUN(xi)
        myx = xmin;
        myx(dims(idim)) = xi;
        f = feval(FUN, myx);
    end

end
