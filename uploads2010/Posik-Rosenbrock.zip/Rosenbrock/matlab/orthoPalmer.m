function xi = orthoPalmer(xi, d)
%
% orthoPalmer Palmer's orthogonalization method
%
% Package: HOAtbx
%
% Description:
%   Function performs orthogonalization as suggested by Palmer in 
%      J.R. Palmer. An improved procedure for orthogonalising the search
%      vectors in Rosenbrock's and Swann's direct search optimisation
%      methods. The Computer Journal, 12(1):69--71, February 1969.
%
% Synopsis:
%   xi = orthoPalmer(xi, d)
%      The function takes the orthogonal basis xi (row vectors) and adapts
%      it using the vector d. The vector d is given in terms of the basis
%      vectors xi, i.e. the real vector is given by 
%      sum_{i=1}^n xi(i,:)*d(i).
%
%      Function returns the new orthonormal basis xi.

    n = size(xi,1);

    A = repmat(d(:),1,n) .* xi;
    ind = n:-1:1;
    A(ind,:) = cumsum(A(ind,:),1);

    t(ind) = cumsum(d(ind).^2);

    for i = n:-1:2,
        div = sqrt(t(i-1)*t(i));
        if (div ~=0),
            xi(i,:) = (d(i-1)*A(i,:) - xi(i-1,:)*t(i)) / div;
        end
    end
    div = sqrt(t(1));
    xi(1,:) = A(1,:) / div;
end