function f = fsphere(x)
    f = sum((x-1).^2);
end