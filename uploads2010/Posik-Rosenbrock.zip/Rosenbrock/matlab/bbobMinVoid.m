function [xmin, fmin, fevals] = bbobMinDirectLineSearch(...
    FUN, x0, ftarget, opts)

D = size(x0,1);

xmin = x0;
fmin = inf;
fevals = 0;

if nargin < 4 || isempty(opts), opts = optimset(); end
defopts = optimset(...
    'MaxFunEvals', 200*D, ... %min(3e3*D, opts.MaxFunEvals), ...
    'TolX', 1e-10, ...
    'Display', 'iter' ...
    );
opts = optimset(defopts, opts);

% Prepare options for DIRECT
diropts.maxevals = min(250, round(opts.MaxFunEvals / D));
diropts.maxits = inf;
diropts.maxdeep = 40;
diropts.testflag = 1; % Global optimum known
diropts.showits = 0;  % Show info
diropts.globalmin = ftarget - 1e-8;
diropts.tol = 1e-8; % 1e-3 * 100/abs(opts.globalmin)
if diropts.globalmin ~= 0,
    diropts.tol = diropts.tol * 100/abs(diropts.globalmin);
else
    diropts.tol = 100*diropts.tol;
end

verbosity = 0;
if strcmp(opts.Display, 'final'), verbosity = 1; end
if strcmp(opts.Display, 'iter'), verbosity = 2; end

% Start the main cycle
while true,

    if ~(...
            (fmin > ftarget) && ...
            (fevals < opts.MaxFunEvals)...
            ),
        %             keyboard;
        break;
    end

    xminchanged = false;
    % Create the order of dimensions randomly
    dims = randperm(D);
    for idim = 1:D,

        % Prepare options for fminbnd
        dopts = diropts;
        dopts.maxevals = min(opts.MaxFunEvals - fevals, diropts.maxevals);
        

%         [xinew,fnew,exitflag,output] = fminbnd(@proxyFUN,-5,5,fminopts);
        problem.f = @proxyFUN;
        [fnew, xinew, hist] = DirectObj(problem, [-5 5], diropts);
        xnew = xmin;
        xnew(dims(idim)) = xinew;
        fevals = fevals + hist(end,2);

        if verbosity >= 2,
            fprintf('Fevals: %d   idim: %d   dim: %d   xi: %.1e -> %.1e   log(fmin-fopt): %.2e\n', ...
                fevals, ...
                idim, ...
                dims(idim), ...
                xmin(dims(idim)), xnew(dims(idim)), ...
                fnew - ftarget + 1e-8);
        end

        if fnew < fmin,
            xminchanged = true;
            xmin = xnew;
            fmin = fnew;
        end

        if (fmin < ftarget) || (fevals >= opts.MaxFunEvals), break; end
    end

    if (fmin < ftarget) || ...
            (fevals >= opts.MaxFunEvals) || ...
            (~xminchanged),
        break;
    end

end

if verbosity >= 1,
    fprintf('Finished. Fevals: %d   Fmin: %.3e\n', fevals, fmin-ftarget+1e-8);
end

%%
    function f = proxyFUN(xi)
        myx = xmin;
        myx(dims(idim)) = xi;
        f = feval(FUN, myx);
    end

end
