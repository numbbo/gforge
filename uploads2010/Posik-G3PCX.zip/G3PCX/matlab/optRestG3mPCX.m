function [x, ilaunch] = optRestG3mPCX(FUN, DIM, ftarget, maxfunevals, varargin)

% minimizes FUN in DIM dimensions by multistarts of fminsearch.
% ftarget and maxfunevals are additional external termination conditions.
% fminsearch was modified to take as input a delta_i to generate
% the first simplex.
% set options, make sure we always terminate

    popsize = 5*DIM;
    fevals = 0;
    options = optimset(...
        'MaxFunEvals', min(1e4*DIM, maxfunevals), ...
        'MaxIter', 2e3*DIM, ...
        'TolFun', 1e-11, ...
        'TolX', 1e-10, ...
        'Display', 'off');
    
    % multistart such that ftarget is reached with reasonable prob.
    for ilaunch = 1:20  % relaunch optimizer up to 100 times

        % Initialize
%         if mod(ilaunch-1, floor(1 + 3 * rand)) == 0
%         if true,
            par = -5 + 10*rand(DIM, popsize); % Random start solution  
%             fprintf('\n Reinit');
%         else
%             % try to improve found solution
%             par = [zeros(DIM,1) eye(DIM)]; 
%             center = mean(par,2);
%             par = repmat(x-center,1,DIM+1) + par;
% %             fprintf(' Improving');
%         end
        
        % try minG3mPCX
        [x fmin myfevals] = minG3mPCX(FUN, par, options, varargin{:});
        fevals = fevals + myfevals;

        if fmin < ftarget %|| fevals >= maxfunevals
            break;
        end
        % if useful, modify more options here for next launch
    end
    
end