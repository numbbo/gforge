function [x, ilaunch] = bbobRestG3PCX(FUN, ...
    DIM, ftarget, outermaxfunevals, innermaxfunevals, varargin)

% minimizes FUN in DIM dimensions by multistarts of bbobMinG3PCX.
% maxfunevals is external termination conditions for the outer 
% algorithm, not for the inner restarted algorithm

    popsize = 5*DIM + 90;
    fevals = 0;
    
    % multistart such that ftarget is reached with reasonable prob.
    for ilaunch = 1:100  % relaunch optimizer up to 100 times

        opts.MaxFunEvals = min( outermaxfunevals-fevals, innermaxfunevals );

        % Initialize
        if mod(ilaunch-1, floor(1 + 3 * rand)) == 0
            par = -5 + 10*rand(DIM, popsize); % Random start solution 
        else
            par = -0.1 + 0.2*rand(DIM, popsize); 
            par = par + repmat(x, 1, popsize); % Start in the neighborhood of the last optimum
        end
        
        % try minG3mPCX
        [x fmin myfevals exitflag output] = bbobMinG3PCX(FUN, par, ftarget, opts, varargin{:});
        fevals = fevals + myfevals;

        if ...
                (fmin < ftarget) || ...
                (fevals >= outermaxfunevals),
            break;
        end
    end
end