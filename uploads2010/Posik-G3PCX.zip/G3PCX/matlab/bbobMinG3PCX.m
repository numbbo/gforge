function [xmin, fmin, fevals, exitflag, output] = ...
    bbobMinG3PCX(FUN, par, ftarget, opts, outOfBndsFcn)

    [D,N] = size(par);

    if nargin < 4 || isempty(opts), opts = optimset(); end
    if nargin < 5, outOfBndsFcn = @(x) false(1,size(x,2)); end
    defopts = optimset(...
        'MaxFunEvals', 3e3*D, ... %min(3e3*D, opts.MaxFunEvals), ...
        'TolFun', 1e-15, ...
        'TolX', 1e-11, ...
        'Display', 'off' ...
        );
    opts = optimset(defopts, opts);
    minDmin = 1e-15;
    Dmin = inf;
    exitflag = [];

    verbosity = 0;
    if strcmp(opts.Display, 'final'), verbosity = 1; end
    if strcmp(opts.Display, 'iter'), verbosity = 2; end        

    % Set the G3 model
    mu = 3;
    lambda = 2;
    r = 2;
    
    x = par;
    fevals = 0;
    f = feval(FUN, x);
    fevals = fevals + N;
    [fmin imin] = min(f);
    
    while true,
    
        if (fmin <= ftarget), exitflag = 'StopFitness'; break; end
        if (fevals >= opts.MaxFunEvals), exitflag = 'MaxFunEvals'; break; end
        if (max(f) - min(f) < opts.TolFun), exitflag = 'TolFun'; break; end
        if (max(max(x,[],2)-min(x,[],2)) < opts.TolX), exitflag = 'TolX'; break; end
        if (Dmin < minDmin), exitflag = 'Dmin'; break; end
        
        % Select parents randomly
        indpar = randIndWithoutRepetition(N, mu, imin);
        xpar = x(:,indpar);
        
        % Generate lambda offspring
        xnew = zeros(D, lambda);
        for ioffs = 1:lambda,
            while true,
                [xnew(:,ioffs), Dminnew] = xoverPCX(xpar);
                Dmin = min(Dmin, Dminnew);
                if ~outOfBndsFcn(xnew), break; end
            end
        end
        % Evaluate offspring
        fnew = feval(FUN, xnew);
        fevals = fevals + lambda;
        
        % Select old members to be replaced from the whole population
        indR = randIndWithoutRepetition(N, r, []);
%         % Select old members to be replaced from the selected parents        
%         i = randIndWithoutRepetition(mu, r, []);
%         indR = indpar(i);
        xRC = [xnew x(:,indR)];
        fRC = [fnew f(indR)];
        [fRC, isort] = sort(fRC);
        xRC = xRC(:,isort);
        x(:,indR) = xRC(:,1:r);
        f(indR) = fRC(1:r);
        [fmin imin] = min(f);
        
        if verbosity >= 2,
            fprintf('Fevals: %d   log(min(f)-ftarget): %.3f   log(max(f)-min(f)): %.3f   log(TolX): %.3f\n', ...
                fevals, ...
                log10(fmin-ftarget), ...
                log10(max(f)-min(f)), ...
                log10(max(max(x,[],2)-min(x,[],2))) );
        end
        
%         if fevals > 5000, keyboard; end
    end
           
    [fmin imin] = min(f);
    xmin = x(:,imin);

    output.FitnessDiff = fmin-ftarget;
    output.FuncCount = fevals;
    output.TolF = max(f) - min(f);
    output.TolX = max(max(x,[],2)-min(x,[],2));
    output.MinD = Dmin;

    if verbosity >= 1,
        fprintf('Finished. Fevals: %d   Fmin: %.3f\n', fevals, min(f));
    end
    
end

function ind = randIndWithoutRepetition(imax, n, include)
    if n > imax, error('The second argument can be at most equal to the first argument.'); end
    ind = zeros(1,n);
    if ~isempty(include),
        ind(1) = include;
    else
        ind(1) = ceil( imax*rand );
    end
    for i = 2:n,
        while true,
            ind(i) = ceil( imax*rand );
            if all(ind(i) ~= ind(1:i-1)), break; end
        end
    end
end
