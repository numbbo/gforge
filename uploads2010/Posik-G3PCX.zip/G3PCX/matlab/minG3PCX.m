function [xmin, fmin, fevals] = minG3PCX(FUN, par, opts, outOfBndsFcn)

    plotfigs = false;
    ftoprint = inf;

    [D,N] = size(par);

    if nargin < 3, opts = optimset(); end
    if nargin < 4, outOfBndsFcn = @(x) false(1,size(x,2)); end
    ftarget = opts.ftarget;
    defopts = optimset(...
        'MaxFunEvals', 1e5*D, ...
        'TolX', 1e-20, ...
        'Display', 'final' ...
        );
    opts = optimset(defopts, opts);

    verbosity = 0;
    if strcmp(opts.Display, 'final'), verbosity = 1; end
    if strcmp(opts.Display, 'iter'), verbosity = 2; end        
    
    % Set the G3 model
    mu = 3; %D+1;
    lambda = 2;
    r = 2;%floor(N/2); % min(10, N);
    
    x = par;
    fevals = 0;
    f = feval(FUN, x);
    fevals = fevals + N;
    [fmin imin] = min(f);
    
    if plotfigs,
        fh = figure; set(fh,'DefaultLineLineWidth',1.5, 'DefaultLineMarkerSize',8);
        axis equal;
    end
    %(max(f) - min(f) > opts.TolFun) && ...
    while true,
        if plotfigs,
            plot(x(1,:),x(2,:),'k.'); hold on;
        end
    
        if ~(fmin > ftarget && ...
                (max(max(x,[],2)-min(x,[],2)) > opts.TolX) && ...
                (fevals < opts.MaxFunEvals)),
%             keyboard;
            break;
        end

        % Select parents randomly
        indpar = randIndWithoutRepetition(N, mu, imin);
        xpar = x(:,indpar);
        
        % Generate lambda offspring
        xnew = zeros(D, lambda);
        for ioffs = 1:lambda,
            while true,
                xnew(:,ioffs) = xoverPCX(xpar);
                if ~outOfBndsFcn(xnew), break; end
            end
        end
        % Evaluate offspring
        fnew = feval(FUN, xnew);
        fevals = fevals + lambda;
        
        if plotfigs,
            plot(xnew(1,:), xnew(2,:), 'rx');
        end
        
        % Select old members to be replaced from the whole population
        indR = randIndWithoutRepetition(N, r, []);
%         % Select old members to be replaced from the selected parents        
%         i = randIndWithoutRepetition(mu, r, []);
%         indR = indpar(i);
        if plotfigs,
            plot(x(1,indR),x(2,indR),'kx');
        end
        xRC = [x(:,indR) xnew];
        fRC = [f(indR) fnew];
        [fRC, isort] = sort(fRC);
        xRC = xRC(:,isort);
        x(:,indR) = xRC(:,1:r);
        f(indR) = fRC(1:r);
        if plotfigs,
            plot(xRC(1,1:r),xRC(2,1:r),'ro'); hold off; drawnow;
        end

        [fmin imin] = min(f);
        
        if verbosity >= 2,
            if log10(fmin) < ftoprint || plotfigs,
                fprintf('Fevals: %d   log(min(f)-ftarget): %.3f   log(max(f)-min(f)): %.3f   log(TolX): %.3f\n', ...
                    fevals, ...
                    log10(fmin), ...
                    log10(max(f)-min(f)), ...
                    log10(max(max(x,[],2)-min(x,[],2))) );
                ftoprint = (log10(fmin)*10 - 1)/10;
            end
        end
        
%         if fevals > 5000, keyboard; end
    end
           
    [fmin imin] = min(f);
    xmin = x(:,imin);
    if verbosity >= 1,
        fprintf('Finished. Fevals: %d   Fmin: %.3f\n', fevals, min(f));
    end
    
end

function d = dist1toN(x, par)
    d = sum( bsxfun(@minus, par, x).^2, 1);
end

function ind = randIndWithoutRepetition(imax, n, include)
    if n > imax, error('The second argument can be at most equal to the first argument.'); end
    ind = zeros(1,n);
    if ~isempty(include),
        ind(1) = include;
    else
        ind(1) = ceil( imax*rand );
    end
    for i = 2:n,
        while true,
            ind(i) = ceil( imax*rand );
            if all(ind(i) ~= ind(1:i-1)) break; end
        end
    end
end
