clc; clear;
more off;  % in octave pagination is on by default
newdiary();

%% Get the path to the bbob directory
bbobpath = pwd;
ind = max(strfind(bbobpath,[filesep 'alg' filesep]));
bbobpath(ind:end) = [];

%% Set the parameters of maxfunevals
outerstr = '5e4*dim';
innerstr = '5e4*dim';
opt.algName = 'G3PCX';  % different name for each experiment
opt.comments = ['restarts up to 100, '...
    sprintf('outermaxfevals %s, inner maxfunevals %s',outerstr,innerstr)];

%% Define folders for results, for results of the particular algorithm and its variant
resultspath = 'results';
algopath = 'g3pcx';
variantpath = [innerstr '_' outerstr]; 
variantpath = strrep(variantpath, '*dim', 'D');

% addpath([bbobpath '\matlab']);  % should point to fgeneric.m etc.
%% Path of data, different folder for each experiment
datapath = fullfile(bbobpath, resultspath, algopath, variantpath, ''); 
% datapath = '.';

%% Copy the m-files to the results
copypath = fullfile(datapath,'matlab','');
mkdir(copypath);
copyfile('*.m', copypath);

t0 = clock;
rand('state', sum(100 * t0));

dims = [2,3,5,10,20,40];
funcs = benchmarks('FunctionIndices');
instances = [1:5 1:5 1:5];

startdim = 40;
startifun = 23;
startinstance = 13;

for dim = dims,  % small dimensions first, for CPU reasons
    if dim < startdim, continue; end
    for ifun = funcs,
        if (dim == startdim && ifun < startifun), continue; end
        for iinstance = 1:numel(instances),  % first 5 function instances, three times
            if (dim == startdim && ifun == startifun && iinstance < startinstance),
                continue;
            end

            fgeneric('initialize', ifun, instances(iinstance), datapath, opt);

            [myx, mylaunch] = bbobRestG3PCX(@fgeneric, dim, fgeneric('ftarget'), ...
                eval(outerstr), eval(innerstr), @isOutside);

            fprintfts(['  f%d in %d-D, instance %d: FEs=%d, #launches=%d' ...
                ' fbest-ftarget=%.4e, elapsed time [h]: %.2f\n'], ...
                ifun, dim, iinstance, ...
                fgeneric('evaluations'), ...
                mylaunch, ...
                fgeneric('fbest') - fgeneric('ftarget') + 1e-8, ...
                etime(clock, t0)/60/60);
            fgeneric('finalize');
        end
        fprintfts('%s\n', ['      date and time: ' num2str(clock, ' %.0f')]);
    end
    fprintfts('---- dimension %d-D done ----\n', dim);
end
