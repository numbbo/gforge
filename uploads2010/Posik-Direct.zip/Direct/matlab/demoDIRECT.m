function demoDIRECT

    DIM = 2;

    diropts.ep = 1e-10;
    diropts.maxevals = 1000;
    diropts.maxits = inf;
    diropts.maxdeep = 21;
    diropts.testflag = 1; % Global optimum known
    diropts.showits = 1;  % Show info
    diropts.globalmin = 1e-8;
    diropts.tol = 1e-8; 
    diropts.tol = 100*diropts.tol;
    
    % Initialize
    bounds = repmat(5*[-1 1], DIM, 1);
 
    Problem.f = @frosen;
    [fmin, x, history, c] = DirectObj(Problem, bounds, diropts);
    
    c = -5 + 10*c;

    figure;
    axis([-5 5 -5 5]);
    h = ezcontour('log10(100*( x^2 - y )^2 + (x-1)^2)', [-5 5 -5 5], 150); hold on;
    plot(c(1,:), c(2,:), 'ko', 'MarkerFaceColor','k', 'MarkerSize', 3);
    title(''); xlabel('x','Fontsize',16); ylabel('y','Fontsize',16);
    set(gca,'FontSize',16);
    set(h,'Linewidth',2);
    print -depsc2 demoDIRECT1
    
    figure;
    axis([0 2 0 2]);
    h = ezcontour('log10(100*( x^2 - y )^2 + (x-1)^2)', [0 2 0 2], 150); hold on;
    plot(c(1,:), c(2,:), 'ko', 'MarkerFaceColor','k', 'MarkerSize', 3); 

    title(''); xlabel('x','Fontsize',16); ylabel('y','Fontsize',16);
    set(gca,'FontSize',16);
    set(h,'Linewidth',2);
    print -depsc2 demoDIRECT2
    

end