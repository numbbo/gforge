function funInfos = benchmarkinfos(funcID)
%
% benchmarkinfos() returns a cell array of strings
% benchmarkinfos(funcID) returns the info string of function funcID
%   where funcID is a number, like 18, or a string, like 'f18'
% Example: 
%   res = benchmarkinfos();
%   disp(sprintf('%s\n', res{:}));
%   disp(sprintf('%s\n', res{101:end}));
%
% displays the full info
%
% See also benchmarks, fgeneric

% On a slow laptop takes an average function value about (less) 1e-4 s in 40-D. 
% The longest (f22) takes 7e-4 s. The times scales roughly linear with DIM. 
% ==> 40*1e6 fevals take on average 1h. 
%

% Read info from file benchmarkinfos, located in the parent folder of this mfile
  filepath = fileparts(mfilename('fullpath'));
  fid = fopen([filepath filesep '..' filesep 'benchmarkinfos.txt'],'r');
  % this opens path/../benchmarkinfos where path is the folder
  % in which this m-file function was found 

  while 1
    tline = fgetl(fid);
    if ~ischar(tline),   break,   end
    if isempty(regexp(tline,'\S','once')) || strcmp(tline(1),'%')
      continue
    end
    funInfos{str2num(strtok(tline))} = tline;
  end

%%   not compatible with octave
%    tmp = textscan(fid,'%d %s','Delimiter','','CommentStyle','%');
%    for i = 1:length(tmp{1})
%      funInfos{tmp{1}(i)} = [num2str(tmp{1}(i)) ' ' tmp{2}{i}];
%    end

  fclose(fid);
  if nargin > 0
    if ischar(funcID)
      funcID = sscanf(funcID, 'f%d');
    end
    funInfos = funInfos{funcID};
  end
