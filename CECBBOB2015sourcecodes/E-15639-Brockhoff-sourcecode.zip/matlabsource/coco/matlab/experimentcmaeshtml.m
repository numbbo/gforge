% runs an entire experiment for benchmarking MY_OPTIMIZER
% on the noise-free testbed. fgeneric.m and benchmarks.m
% must be in the path of Matlab/Octave
% CAPITALIZATION indicates code adaptations to be made

addpath('../');  % should point to fgeneric.m etc.
datapath = 'bbobdata-cmaeshtml-noise-long';  % different folder for each experiment
opt.algName = 'cmaeshtml V3.23.beta';
opt.comments = 'sigma0=2 maxfunevals=1e4*DIM restarts=8 maxiter=100 + 300 * N * sqrt(N/popsize)';
maxfunevals = '1e5 * dim';

more off;  % in octave pagination is on by default

t0 = clock; 
rand('state', sum(100 * t0));

for dim = [5,2,3,10,20,40]  % small dimensions first, for CPU reasons
  for ifun = benchmarksnoisy('FunctionIndices')
    for iinstance = reshape([1:5; 1:5; 1:5], 1, 15)  % first 5 function instances, three times 
      fgeneric('initialize', ifun, iinstance, datapath, opt); 

      runcmaeshtml('fgeneric', dim, fgeneric('ftarget'), eval(maxfunevals));

      disp(sprintf(['  f%d in %d-D, instance %d: FEs=%ld,' ...
                    ' fbest-ftarget=%.4e, elapsed time [h]: %.2f'], ...
                   ifun, dim, iinstance, ...
                   fgeneric('evaluations'), ...
                   fgeneric('fbest') - fgeneric('ftarget'), ...
                   etime(clock, t0)/60/60));
      fgeneric('finalize');
    end
    disp(['      date and time: ' num2str(clock, ' %.0f')]);
  end
  disp(sprintf('---- dimension %d-D done ----', dim));
end
