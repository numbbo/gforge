function [x, ilaunch, f] = MY_OPTIMIZER(FUN, DIM, ftarget, maxfunevals)
% minimizes FUN in DIM dimensions by multistarts of fminsearch. 
% ftarget and maxfunevals are additional external termination conditions,
% where at most 2 * maxfunevals function evaluations are conducted. 
% fminsearch was modified to take as input variable usual_delta to 
% generate the first simplex. 

  % set options, make sure we always terminate 
  % with restarts up to 2*maxfunevals are allowed
  options = optimset('MaxFunEvals', min(1e9*DIM, maxfunevals), ...
                     'MaxIter', 2e3*DIM, ... % overwritten later
                     'Tolfun', 1e-11, ...
                     'TolX', 1e-11, ...
                     'OutputFcn', @callback, ... 
                     'Display', 'off');

  ilocal = 0;

  % multistart such that ftarget is reached with reasonable prob.
  for ilaunch = 1:1e5;  % relaunch optimizer up to 1e5 times 
    % set initial conditions
    ilocal = ilocal + 1;
    if ilocal == 1  % (re-)start from scratch
      xstart = 8 * rand(DIM, 1) - 4;  % random start solution
      usual_delta = 2;
      options = optimset(options, 'MaxIter', floor(200*sqrt(DIM)));
    else  % refining restart run
      xstart = x;  % try to improve found solution 
      usual_delta = 10 * range(v,2);  % a bit of regularization in given coordinate sys
      if rand(1,1) < 0.2  %  a bit of desperatation 
        usual_delta = usual_delta + (1/ilocal) * (0.1/ilocal).^rand(DIM,1);  
      end
      if rand(1,1) < 0.1 * (ilocal-10)/sqrt(DIM)  % final run 
        options = optimset(options, 'MaxIter', 500*DIM); % long run
        ilocal = 0;           % real restart after this run
      end
    end

    % try fminsearch from Matlab, modified to take usual_delta as arg
    [x,f,e,o,v] = fminsearch_mod(FUN, xstart, usual_delta, options);  
    % disp(sprintf('%d %d: %e  %e %e', ilocal, feval(FUN, 'evaluations'), f-ftarget, ... 
    %               min(usual_delta), max(usual_delta)/min(usual_delta)));

    if feval(FUN, 'fbest') < ftarget || ...
          feval(FUN, 'evaluations') >= maxfunevals 
      break;  
    end
    % if useful, modify more options here for next launch
  end 

  function stop = callback(x, optimValues, state)
    stop = false;
    if optimValues.fval < ftarget
      stop = true;
    end
  end
  
end