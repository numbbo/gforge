% this still looks like a stump, but it is already quite useful
clear benchmarks; 
arrfh = benchmarks('handles');  % function handles
h2 = benchmarksnoisy('handles');
arrfh(100+(1:length(h2))) = h2;  % index and function ID must agree
benchmarks(); benchmarksnoisy(); 
clear benchmarks; benchmarks();
fidx = benchmarks('noisefreeFunctionIndices');
if length(fidx) ~= 24, 
  error('number of functions changed or a function does not execute');
end
fidx = benchmarksnoisy('FunctionIndices');
if length(fidx) ~= 30, 
  error('number of noisy functions changed or a function does not execute');
end
arrDIM = [2:20 40 10:-1:5]; 
for DIM = arrDIM
  if 1 < 3 && DIM == 3
    clear benchmarks benchmarksnoisy; 
  end
  for ifun = randperm(200)
    if length(arrfh) >= ifun && ~isempty(arrfh{ifun})
      fun = arrfh{ifun};
      Fopt = fun(''); % string arg returns always fopt
      if isempty(Fopt), error(' funcID and name disagree?'); end
      if Fopt ~= fun('another test'), error(' '); end
      [ignore, ID] = fun('info');  % info is any string case
      if ~exist('fflush', 'builtin')  % only in matlab
        % if sscanf(ID, '%d') == ifun, else, error(' '); end % ~= fails
      end
      % get/check Xopt
      [Fopt2, Xopt] = fun('xopt', DIM);
      [Fopt2, Xopt] = fun('xopt', DIM);
      if size(Xopt,1) ~= DIM, fun, error(' '); end
      if Fopt ~= Fopt2, error(' '); end
      if fun(Xopt) - Fopt > DIM*1e-12 
        fun, error(['f(Xopt)-Fopt==' num2str(fun(Xopt) - Fopt)]); 
      end

      % Test parallelization 
      x = 10.2 * rand(DIM, 2 + ceil(300*rand)) - 5.1; 
      [f ftrue] = fun(x);
      [ignore ff] = fun(x(:,2)); 
      % function values are the same? 
      if ftrue(2) - ff > 0 && (ftrue(2) - ff) / ff > 1e-9, fun, error(' '); end

    end
  end
  if DIM <= arrDIM(1) + 2
    disp(['no error for DIM=' num2str(DIM)]);
  end
end
disp('no error found, starting timing in [s/1e4 fevals]');

for DIM = [4 40] % max(arrDIM)
  for ifun = 1:200
    if length(arrfh) >= ifun && ~isempty(arrfh{ifun})
      fun = arrfh{ifun};
      tic; 
      for k = 1:1e1, 
        fun(rand(DIM,1000));
      end
      t(ifun) = toc;
      if 11 < 3 || ifun == 1 || t(ifun) > 30 * t(1)
        disp(sprintf('%3d %d %6.2f', ifun, DIM, t(ifun))); 
      end
    end
  end
  disp(sprintf(' DIM = %d: overall %6.2f + %6.2f ', ...
               DIM, sum(t(1:99)), sum(t(100:end))));  
end

% read in data file and compare f-values with evaluated ones

% check specific function values inside bound location

% check specific function value at outside bound location


