function [XMIN, FMIN, COUNTEVAL, STOPFLAG, OUT, BESTEVER] = ...
            runcmaesnoisy(FUN, DIM, ftarget, maxfunevals)
% MY_OPTIMIZER(FUN, DIM, ftarget, maxfunevals)

  opts.restarts = 9;  % 2^9 == 512
  % opts.maxiter = '100 + 300 * N * sqrt(N/popsize)';
  opts.maxiter = '1000 + 500 * (N+3)^2 / sqrt(popsize)';
  opts.maxrestartfunevals = min(1e9 * DIM, maxfunevals); 
  opt.tolupx = inf;  % replaced internally with "tolupsigma"

% opts.popsi = 'ceil(10 + 100*N)';
  opts.noise.on = 0;
  opts.noise.eps = 02.6;  % triggers median measure


  % speed and output options
  opts.stopfitness = ftarget;
  opts.evalpar = 1;

  if 1 < 3  % run silently
    opts.savevar = 'off'; 
    opts.dispfinal = 0;
    opts.dispmod = 0;
    opts.logmod = 0;
  end

  [XMIN, FMIN, COUNTEVAL, STOPFLAG, OUT, BESTEVER] = ...
    cmaes(FUN, ['8*rand(' num2str(DIM) ', 1) - 4'], 2, opts);
  
  
