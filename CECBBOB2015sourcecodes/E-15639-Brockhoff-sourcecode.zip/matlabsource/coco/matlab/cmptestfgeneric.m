% unit test for fgeneric
% rev 743: tests more features.
% As of later revisions, the unit test of fgeneric is simplified so as to
% compare with other simpler versions of fgeneric.

clear all;

% Put dbstop here if needed.

t0 = clock;

% To unit test noisy benchmark: rename myrand and myrandn to rand and randn
% for fun = 101:130
for fun = 1:24
  for dim = [2 3 5 10 20 40]
    for instance = 1:15
      disp(sprintf('%d-D f%d, trial: %d', dim, fun, instance));
      %fgeneric('initialize', fun, instance, 'cmptestfolder');
      for i = 1:1001
        %fgeneric(20 * unif(dim,i)' - 10);
        20 * unif(dim,i)' - 10;
      end
      %fgeneric('finalize');
      disp(sprintf('\tDone, time elapsed [h] %.2f', etime(clock, t0)/60/60));
    end
  end
end
