% generate pictures for technical documentation

% INPUT parameters

dimSection = [3,5,10,40];  % contains dimensions for which the section graphs should be generated
dimContour = [2,20];   % contains dimensions for which the contour graphs should be generated
functions = [106]; 
flgclose = 0;        % close figure at the end 
plt3D = 1;           % generate 3d plot
dimSection = [10]; % overwriting default values from above
dimContour = [];     % overwriting default values from above

% The default surfaces for the contourplots are:
% x1 - x2
% x1 - dim/4 (e.g., for dim = 20 -> x1-x5)
% x1 - dim/2 (e.g., for dim = 20 -> x1-x10
% x1 - dim   (e.g., for dim = 20 -> x1-x20)
% Each contourplot will only created once. For exeptions (dim = 3 and dim =
% 5) the following contourplot will be created:
% x2 - x3 

% get benchmark handles
handles = benchmarks('handles');
h2 = benchmarksnoisy('handles');
handles(100+(1:length(h2))) = h2;  % index and function ID must agree

for h = functions

    % check if empty
    if isempty(handles{h})
        continue
    end

    % default values
    xMin = -13;             % minimum for logspaced vector (logarithmic value)
    xMaxLogLog = 5.5;       % maximum for logspaced vector (coordinate value)
    xMaxOther = 5.0;        % for semilog and normalized section plots
    yMinSL = 1e-8;          % y-axis minimum for semilog section plot
    yMaxSL = 1e99;          % y-axis maximum for semilog section plot
    yMinLL = 1e-8;          % y-axis minimum for loglog section plot
    yMaxLL = 1e99;          % y-axis maximum for loglog section plot
    az = -37.5;             % azimuth for 3D-view
    el = 30;                % elongation for 3D-view
    nContour = 20;          % number of contour lines
    nPoints = 1000;         % number of points for section plots
    zDirSurf = 'reverse';   % direction of the z-Axis for the surface plot
    legendLocLL = 'southeast';   % location of the legend in the loglog plot
    legendLocN = 'north';    % location of the legend in the normalized plot
    legendLocSL = 'southeast';   % location of the legend in the semilog plot   
    logData = 'no';         % show 2-D surf plot with log data
    showArrow1 ='noshow';   % arrow indicates location of optimum in 2d contour plot
    showArrow2 ='noshow';   % arrow indicates location of optimum in all other contour plots
    logDataContour2d = 'log';   % show 2d contour with log data
    logDataContour = 'log';     % show all other contour plots with log data
    fcauchy = 0;             % for removing the plateaus in the cauchy plots
    nDomain = 100;           % number of points per axis for 3d plot
    Znotshow = 1e99;         % values larger than this wont be shown in the 3d plot
    
    % function specific values
    switch func2str(handles{h})

        case 'f1'
            xMin = -5;            
            yMinSL = 1e-5;
            az = 135;             
            el = 20;
            
        case 'f2'
            xMin = -8;            
            az = 110;             
            el = 20;
            showArrow1 = 'show';
            yMinSL = 1e-5;
            legendLocLL = 'northwest';
            %logData = 'yes';
            
        case 'f3'
            xMin = -2;
            az = 115;
            el = 35;
            showArrow1 = 'show';
            showArrow2 = 'show';
            legendLocSL = 'southwest';
            yMinSL = 1e-3;
            yMinLL = 1e-3;
            
        case 'f4'
            xMin = -3;
            az = 70;
            el = 40;
            showArrow1 = 'show';
            showArrow2 = 'show';
            legendLocSL = 'southwest';
            yMinSL = 1e-3;
            yMinLL = 1e-3;
            
        case 'f5'
            az = -120;
            el = 30;
            zDirSurf = 'normal';            
            %legendLocSL = 'best';
            legendLocSL = 'south'; % use for DIM = (10,40)
            nContour = 100;
            xMin = -10;
            yMinSL = 1e-2;
            
        case 'f6'            
            xMin = -6;
            yMinSL = 1e-2;
            az = 160;
            el = 25;
            %logData = 'yes';
            if strcmp(logData,'yes')
                az = 100;
                el = 40;
            end
            
        case 'f7'
            az = 195;
            el = 30;
            xMin = -2;
            showArrow1 = 'show';
            
        case 'f8'
            az = -10;
            el = 30;
            xMin = -2;
            showArrow1 = 'show';
            yMinSL = 1e-3;
            yMinLL = 1e-4;
            legendLocLL = 'northwest';
            logData = 'yes';
            nDomain = 750;
            
        case 'f9'
            az = 60;
            el = 45;
            xMin = -2;
            showArrow1 = 'show';
            yMinSL = 1e-3;
            yMinLL = 1e-2;
            legendLocLL = 'northwest';
            logData = 'yes';
            nDomain = 750;
            
        case 'f10'
            %az = -42;
            %el = 28;
            xMin = -5;  
            showArrow1 = 'show';
            legendLocSL = 'southwest';
            yMinSL = 1e-4;
            yMinLL = 1e-5;
            Znotshow = 1e7;
            az = 260;
            el = 50;
            nDomain = 200;
            
        case 'f11'
            %az = 135;
            %el = 30;
            xMin = -5;  
            showArrow1 = 'show';
            showArrow2 = 'show';
            yMinSL = 1e-3;
            yMinLL = 1e-5;
            Znotshow = 1e7;
            az = -20;
            el = 40;
            nDomain = 200;
            
        case 'f12'
            %az = -50;
            %el = 40;
            xMin = -2;
            yMinSL = 0;
            yMinLL = 1e-4;
            legendLocLL = 'northwest';  
            showArrow1 = 'show';
            Znotshow = 5e7;
            az = 155;
            el = 40;
            nDomain = 200;
            
        case 'f13'
            az = -160;
            el = 30;
            xMin = -8; 
            yMinSL = 1e-1;
            showArrow1 = 'show';
            
        case 'f14'
            xMin = -2;
            %az = -20;
            %el = 25;
            legendLocN = 'best'; 
            legendLocSL = 'southwest'; 
            legendLocLL = 'northwest'; 
            yMinSL = 1e-3;
            yMinLL = 1e-2;
            logData = 'yes';
            az = -58;
            el = 40;
            
        case 'f15'
            xMin = -2;
            az = -150;
            el = 25;
            nContour = 50;  
            showArrow1 = 'show';
            yMinSL = 1e-3;
            yMinLL = 1e-2;
            
        case 'f16'
            xMin = -3;
            az = 162;
            el = 35;  
            legendLocN = 'best';  
            showArrow1 = 'show';
            yMinSL = 1e-2;
            yMinLL = 1e-2;
            nDomain = 200;
            
        case 'f17'
            xMin = -6;
            az = -125;
            el = 25;  
            legendLocSL = 'southwest';   
            logData = 'yes';
            showArrow1 = 'show';
            yMinSL = 1e-3;
            yMinLL = 1e-6;
            
        case 'f18'
            xMin = -4;
            az = -125; az = 52;
            el = 23;  el = 22;
            legendLocSL = 'southwest';   
            logData = 'yes';
            showArrow1 = 'show';
            yMinSL = 1e-2;
            yMinLL = 1e-4;
            nDomain = 200; 
            
        case 'f19'
            xMin = -2;
            az = -130;
            el = 30; 
            nContour = 25;
            showArrow1 = 'show';
            showArrow2 = 'show';
            yMinLL = 1e-4;
            
        case 'f20'
            logData = 'yes';
            nDomain = 200; 
            %Znotshow = 5e4;
            az = -80;
            el = 21; 
            xMin = -2;
            showArrow1 = 'show';
            showArrow2 = 'show';
            yMinSL = 1e-5;
            yMinLL = 1e-4;
            legendLocLL = 'northwest'; 
            
        case {'f21','f22'}
            nContour = 30;
            xMin = -1;
            yMinLL = 1e-2;
            %legendLocLL = 'northwest'; 
            nDomain = 200;
            
        case 'f23'
            xMin = -3;
            legendLocN = 'best';  
            nContour = 5;
            showArrow1 ='show';
            showArrow2 = 'show';
            logDataContour2d = 'nolog';
            az = -140;
            el = 14; 
            logData = 'yes';
            yMinSL = 1e-1;
            yMinLL = 1e-2;
            legendLocSL = 'south'; 
            nDomain = 50;
            
        case 'f24'
            xMin = -2;    
            nContour = 15;
            az = -153;
            el = 25;
            showArrow1 ='show';
            showArrow2 = 'show';
            yMinSL = 1e-1;
            yMinLL = 0;
            legendLocLL = 'northwest';
            
        case 'f101'
            xMin = -1;    
            az = 135;
            el = 50;
            yMinSL = 1e-6;
            yMinLL = 1e-2;
            
        case 'f102'
            xMin = -1;
            nContour = 30; 
            yMinLL = 1e0;
            yMaxLL = 1e2;
            yMinSL = 1e-1;
            az = -140;
            el = 30;
            
        case 'f103'
            xMin = -4;
            %xMin = -8;
            az = 215;
            el = 40;
            legendLocSL = 'north';
            %legendLocLL = 'best';
            fcauchy = 10;
            yMinSL = 1e0;
            yMaxLL = 10^(1.2);
            yMinLL = 10^(0.8);
            
        case 'f104'
            xMin = -2;
            %az = 140;
            %el = 25;                
            showArrow1 = 'show';
            showArrow2 = 'show';
            legendLocLL = 'northwest';
            yMinSL = 1e-4;
            yMinLL = 1e-3;
            logData = 'yes';
            nDomain = 400;
            az = -15;
            el = 60;
            
        case 'f105'
            xMin = -2;
            %az = 140;
            %el = 25;                
            showArrow1 = 'show';
            showArrow2 = 'show';
            legendLocLL = 'northwest';
            yMinSL = 1e-4;
            yMinLL = 1e-3;
            logData = 'yes';
            nDomain = 400;
            az = -15;
            el = 40;
            
        case 'f106'
            xMin = -5;
            %az = 140;
            %el = 25;                
            showArrow1 ='show';
            showArrow2 ='show';
            yMinSL = 1e-2;
            fcauchy = 10;
            logData = 'yes';
            nDomain = 200;
            az = -24;
            el = 56;
            yMaxLL = 10^(2.5);
            yMinLL = 10^(0.9);
            legendLocLL = 'northwest';
            
        case 'f107'
            xMin = -5;
            az = -60;
            el = 25;                
            %legendLocSL = 'north';
            logData = 'yes';
            nContour = 10;
            yMinSL = 1e-6;
            
        case 'f108'
            xMin = -4;
            az = -55;
            el = 25;                
            %legendLocSL = 'southwest';
            logData = 'yes';
            nContour = 5; 
            showArrow1 ='show';   
            showArrow2 ='show'; 
            yMinSL = 1e-5;
            
        case 'f109'
            xMin = -4;
            az = 65;
            el = 15;  
            nContour = 100;
            logDataContour2d = 'nolog';
            logDataContour = 'nolog';
            showArrow1 ='show';   
            showArrow2 ='show'; 
            legendLocSL = 'north';
            legendLocN = 'best';
            fcauchy = 1000;
            yMinSL = 1e2;
            yMaxLL = 10^(3.1);
            yMinLL = 10^(2.75);
            
        case 'f110'
            xMin = -6;  
            nContour = 10;
            %legendLocSL = 'southwest';
            logData ='yes';
            showArrow1 ='show';   
            showArrow2 ='show'; 
            yMinSL = 1e-3;
            az = -24;
            el = 42;
            
        case 'f111'
            xMin = -5; 
            nContour = 7;
            az = -15;
            el = 50; 
            %legendLocSL = 'southwest';
            logData ='yes';
            showArrow1 ='show';   
            showArrow2 ='show'; 
            yMinSL = 1e-4;
            
        case 'f112'
            xMin = -5; 
            legendLocSL = 'north';
            showArrow1 ='show'; 
            fcauchy = 1000;
            yMinSL = 1e2;
            logData = 'yes';
            nDomain = 200;
            az = -22;
            el = 14;
            yMaxLL = 10^(3.2);
            yMinLL = 10^(2.6);
            legendLocLL = 'northwest';
            
        case 'f113'
            xMin = -3;    
            nContour = 10;
            logData ='yes';
            az = -121;
            el = 28; 
            %legendLocSL = 'southwest';
            showArrow1 = 'show';
            
        case 'f114'
            xMin = -3;    
            nContour = 7;
            logData ='yes';
            showArrow1 ='show';   
            showArrow2 ='show'; 
            az = 130;
            el = 30;
        
        case 'f115'
            xMin = -3;
            legendLocN = 'best';
            nContour = 30;
            showArrow1 ='show';   
            showArrow2 ='show'; 
            logDataContour2d = 'nolog';
            logDataContour = 'nolog';
            fcauchy = 1000;
            az = 70;
            el = 20;
            yMinSL = 1e2;
            yMinLL = 10^(2.5);
            yMaxSL = 1e4;
            yMaxLL = 10^(3.2);
            %legendLocLL = 'best';
        
        case 'f116'
            xMin = -6;
            nContour = 10;
            showArrow1 ='show';   
            logData ='yes';
            az = -115;
            el = 25;
            yMinSL = 1e-3;
            
        case 'f117'
            xMin = -5;
            nContour = 7;
            showArrow1 ='show';   
            showArrow2 ='show'; 
            logData ='yes';
            az = 165;
            el = 50;
            yMinSL = 1e-3;
            
        case 'f118'
            xMin = -5;
            showArrow1 ='show';   
            az = 25;
            el = 20;
            fcauchy = 1000;
            yMinSL = 1e-2;
            %Znotshow = 1e5;
            logData = 'yes';
            %nDomain = 10;
            yMaxLL = 10^(3.2);
            yMinLL = 10^(2.7);
            legendLocSL = 'southwest';
            legendLocLL = 'best';
            
        case 'f119'
            xMin = -6;
            nContour = 10;
            legendLocLL = 'northwest';
            legendLocSL = 'southwest';
            logData ='yes';
            az = -45;
            el = 50;
            yMinSL = 1e-3;
            
        case 'f120'
            xMin = -8;
            nContour = 5;
            showArrow1 ='show';   
            showArrow2 ='show';
            logData ='yes';
            az = 105;
            el = 45;
            yMinSL = 1e-4;
            
        case 'f121'
            xMin = -7;
            showArrow1 ='show';   
            showArrow2 ='show';
            legendLocN = 'best';
            legendLocLL = 'best';
            legendLocSL = 'north';
            logDataContour2d = 'nolog';
            logDataContour = 'nolog';
            nContour = 25;
            fcauchy = 1000;
            az = 20;
            el = 10;
            yMinSL = 1e2;
            yMaxSL = 1e4;
            yMaxLL = 10^(3.25);
            yMinLL = 10^(2.75);
            
        case {'f122','f123'}
            xMin = -8;
            nContour = 7;
            showArrow1 ='show';   
            showArrow2 ='show';
            logData ='yes';
            az = -48;
            el = 50;
            yMinSL = 1e-4;
            
        case 'f124'
            xMin = -8;
            showArrow1 ='show';   
            showArrow2 ='show';
            legendLocN = 'best';  
            legendLocSL = 'north';
            legendLocLL = 'best';
            %logData ='yes';
            fcauchy = 1000;
            yMinSL = 1e2;
            az = 135;
            el = 15;
            %nDomain = 50;
            yMaxLL = 10^(3.1);
            yMinLL = 10^(2.7);
            
        case {'f125','f126'}
            xMin = -3;
            nContour = 7;
            showArrow1 ='show';   
            showArrow2 ='show';
            logData ='yes'; 
            az = 30;
            el = 55;
            
        case 'f127'
            xMin = -3;
            nContour = 10;
            showArrow1 ='show';   
            showArrow2 ='show';
            legendLocN = 'best';
            legendLocLL = 'best';
            legendLocSL = 'best';
            fcauchy = 1000;
            az = -140;
            el = 5;
            nDomain = 75;
            yMinSL = 10^(2.5);
            yMaxLL = 10^(3.1);
            yMinLL = 10^(2.7);
            
        case 'f128'
            xMin = -3;
            nContour = 7;
            logData ='yes'; 
            showArrow1 ='show';   
            az = 135;
            el = 25;
        
        case 'f129'
            xMin = -3;
            nContour = 5;
            logData ='yes'; 
            showArrow1 ='show';   
            showArrow2 ='show';
            yMinSL = 1e-3;
            
        case 'f130'
            xMin = -3;
            legendLocN = 'best';
            showArrow1 ='show';   
            showArrow2 ='show';
            fcauchy = 1000;
            %logData = 'yes';
            %nDomain = 50;
            az = -45;
            el = 20;
            yMinLL = 10^(2.75);
            yMaxLL = 10^(3.1);
            yMinSL = 10^(2);
            legendLocSL = 'north';
            legendLocLL = 'best';
    end
    
    % generate domain
    x = linspace(-20,20,4*nDomain)';
    [x1,x2] = meshgrid(x,x);
    
    % generate data
    clear Z;
    for i = 1:size(x,1)
        Z(i,:) = handles{h}([x1(i,:);x2(i,:)]);
    end
    
    % determine fopt and xopt for 2-D
    [fOpt,xOpt] = feval(handles{h}, 'xopt', 2);
 
    if strcmp(logData,'yes')
        Zsurf = log10(Z-fOpt+1e-9);
        zLabel = 'log_{10}(f - f_{opt})';
    else
        Zsurf = Z;
        Zsurf(Zsurf>Znotshow) = NaN;
        zLabel = 'f';
    end
    
   
    %%%%%%%%%%%%%%%%%%%%%%%%%%%% Surface Plot %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    if plt3D
        figure('Position',[1 700 700 700])
        surf(x1,x2,Zsurf,'EdgeLighting','gouraud','EdgeColor','none');
        set(gcf,'PaperPositionMode','auto','PaperType','A4')
        view(az,el)
        xlabel('x_1','FontSize',20);
        ylabel('x_2','FontSize',20);
        zlabel(zLabel,'FontSize',20)
        set(gca,'FontSize',20)
        set(gca,'XTick',-5:2.5:5,'YTick',-5:2.5:5)
        set(gca,'ZDir',zDirSurf)
        grid on
        %axis([-5 5 -5 5 min(min(Zsurf)) max(max(Zsurf))])
        shading interp
    
%         file1 = strcat(func2str(handles{h}),'3D');
%         print('-dpng','-zbuffer','-loose',file1) 
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%% Contour Plots %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    if max(dimContour == 2) == 1    % generate 2-D - contour
        % 2-D plot with from already existent data
        contourPlot(x,Z,fOpt,nContour,xOpt,showArrow1,logDataContour2d)
%         file2 = strcat(func2str(handles{h}),'Contour');
%         print('-dpng',file2)
    end
    
    % multi dimensional contour plots
    for d = 1:length(dimContour)
        
        % skip if dimContour == 2
        if dimContour(d) == 2
            continue
        end
        
        % determine respective optima
        [fOpt,xOpt] = feval(handles{h}, 'xopt', dimContour(d));
        
        % set coordinates
        secondAxis = setdiff(unique([2 round(dimContour(d)/4) round(dimContour(d)/2) dimContour(d)]), 1);
    
        clear Z1;
        for j = 1:length(secondAxis)
            for i = 1:size(x,1)
                Z1(i,:) = handles{h}([x1(i,:);xOpt(2:secondAxis(j)-1)*ones(1,nDomain);...
                                      x2(i,:);xOpt(secondAxis(j)+1:end)*ones(1,nDomain)]);
            end

            % contourplot in the surface
            contourPlot(x,Z1,fOpt,nContour,[xOpt(1);xOpt(secondAxis(j))],showArrow2,logDataContour)
            ylabel(strcat('x_{',num2str(secondAxis(j)),'}'),'FontSize',20) % rewrite ylabel
%             file2 = strcat(func2str(handles{h}),'Contour1',num2str(secondAxis(j)),'DIM',num2str(dimContour(d)));
%             print('-dpng',file2)
            
%             % might be interesting to look at
%             figure(j*100)
%             surf(Z1)
    
            clear Z1    % deallocate up the Z* - parameter
        
        end
        
        if length(secondAxis) <= 4
            
            % create additionally the x2-x3 contour plot
            for i = 1:size(x,1)
                Z1(i,:) = handles{h}([xOpt(1)*ones(1,nDomain);x1(i,:);x2(i,:);xOpt(4:end)*ones(1,nDomain)]);
            end
            
            contourPlot(x,Z1,fOpt,nContour,[xOpt(2);xOpt(3)],showArrow2,logDataContour)
            xlabel('x_{2}','FontSize',20) % rewrite xlabel
            ylabel('x_{3}','FontSize',20) % rewrite ylabel
%             file2 = strcat(func2str(handles{h}),'Contour23DIM',num2str(dimContour(d)));
%             print('-dpng',file2)    
            
%             % might be interesting to look at
%             figure(500)
%             surf(Z1)    
            
        end
        
    end
    
    % if no section plots should be generated
    if isempty(dimSection)
      continue
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%% Section Plots %%%%%%%%%%%%%%%%%%%%%%%%%%%
    for j = 1:length(dimSection)
    
        % generate data
        [xValues,fValues,xOpt] = DataCutPlot(dimSection(j),xMin,nPoints,handles{h},xMaxLogLog,xMaxOther);
        
        % log-log plot
        figure('Position',[1 700 700 700])
        loglog(xValues(1,:),fValues(1,:),'r','LineWidth',3)
        hold on
        loglog(xValues(1,:),fValues(2,:),'r--','LineWidth',3)
        loglog(xValues(2,:),fValues(3,:),'g','LineWidth',3)
        loglog(xValues(2,:),fValues(4,:),'g--','LineWidth',3)
        loglog(xValues(2,:),fValues(5,:),'b','LineWidth',3)
        loglog(xValues(2,:),fValues(6,:),'b--','LineWidth',3)        
        % redefine y-axis limits
        axis tight
        yLimits = ylim;
        ylim([max(yMinLL,yLimits(1)) min(yLimits(2),yMaxLL)]);
        % legend and format settings
        grid on
        set(gca,'YMinorGrid','off','XMinorGrid','off')
        set(gca,'YMinorTick','on','XMinorTick','on')
        set(gca,'FontSize',20)
        legend('x1',...
               '-x1',...
               'x2',...
               '-x2',...
               'ones',...
               '-ones',...
               'location',legendLocLL)                
        set(gcf,'PaperPositionMode','auto','PaperType','A4')
        ax = axis;
        text(ax(1)*(ax(2)/ax(1))^0.45,ax(4), [num2str(dimSection(j)) '-D'], ...
            'FontSize',20, 'VerticalAlignment','bottom'); 
%         file3 = strcat(func2str(handles{h}),'CutDIM',num2str(dimSection(j)));
%         print('-dpng',file3)

        % normal plot
        figure('Position',[1 700 700 700])
        plot(xValues(3,:),fValues(8,:),'r','LineWidth',3)
        hold on
        plot(xValues(3,:),fValues(10,:),'g','LineWidth',3)
        plot(xValues(3,:),fValues(12,:),'b','LineWidth',3)
        % plot domain border for ones - curves
        [val,id] = min(abs(min(xOpt) + 5 - xValues(3,:))); % left side border
        plot(xValues(3,id),fValues(12,id),'kd','LineWidth',3,'MarkerSize',15)
        [val,id] = min(abs(max(xOpt) - 5 - xValues(3,:))); % right side border
        plot(xValues(3,id),fValues(12,id),'kd','LineWidth',3,'MarkerSize',15)
        set(gca,'XTick',-5:2.5:5)
        grid on
        set(gca,'YMinorGrid','off','XMinorGrid','off')
        set(gca,'FontSize',20)
        legend('x1',...
               'x2',...
               'ones',...
               'location',legendLocN)
        set(gcf,'PaperPositionMode','auto','PaperType','A4')
        ax = axis;
        text(ax(1)+0.45*(ax(2)-ax(1)),ax(4), [num2str(dimSection(j)) '-D'], ...
            'FontSize',20, 'VerticalAlignment','bottom'); 
%         file4 = strcat(func2str(handles{h}),'Cut2DIM',num2str(dimSection(j)));
%         print('-dpng',file4)

        % semi-log plot
        figure('Position',[1 700 700 700])
        semilogy(xValues(4,:),fValues(7,:),'r','LineWidth',3)
        hold on
        semilogy(xValues(4,:),fValues(9,:),'g','LineWidth',3)
        semilogy(xValues(4,:),fValues(11,:),'b','LineWidth',3)
        % plot domain border for ones - curves
        [val,id] = min(abs(min(xOpt) + 5 - xValues(4,:))); % left side border
        plot(xValues(4,id),fValues(11,id),'kd','LineWidth',3,'MarkerSize',15)
        [val,id] = min(abs(max(xOpt) - 5 - xValues(4,:))); % right side border
        plot(xValues(4,id),fValues(11,id),'kd','LineWidth',3,'MarkerSize',15)
        % redefine y-axis limits
        axis tight
        yLimits = ylim;
        ylim([max(yMinSL,yLimits(1)) min(yLimits(2),yMaxSL)]);
        % set format settings
        set(gca,'XTick',-5:2.5:5)
        grid on
        set(gca,'YMinorGrid','off','XMinorGrid','off')
        set(gca,'YMinorTick','on','XMinorTick','off')
        set(gca,'FontSize',20)
        legend('x1',...
               'x2',...
               'ones',...
               'location',legendLocSL)
        set(gcf,'PaperPositionMode','auto','PaperType','A4')
        ax = axis;
        text(ax(1)+0.45*(ax(2)-ax(1)),ax(4), [num2str(dimSection(j)) '-D'], ...
            'FontSize',20, 'VerticalAlignment','bottom'); 
%         file5 = strcat(func2str(handles{h}),'Cut3DIM',num2str(dimSection(j)));
%         print('-dpng',file5)

    end
    
    if flgclose
      close all;  
    end
    
end
