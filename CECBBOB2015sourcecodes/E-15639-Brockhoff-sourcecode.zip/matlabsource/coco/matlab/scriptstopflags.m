% load variables from experimentcmaes with arout
arfid = [];
arsel = {};
stopflags = {};  % flatten all stop flags
for i=1:length(arout)
  o = arout{i};
  for j = 1:length(o.ar.stopflags)
    s = o.ar.stopflags{j};
    for k = 1:length(s)
      stopflags{end+1} = s{k};
      if strcmp(s{k}, 'tolfun') 
         if length(s) == k || ~strcmp(s{k+1}, 'tolhistfun')  % tolfun w/o tolhistfun
            disp(sprintf('  only tolfun (not histfun) for [f instance dim] = [%s]', num2str(o.funIdim)));
         end
      end
      if strcmp(s{k}, 'tolupx')
         disp(sprintf('  tolupx for [f instance dim lam iter] = [%s %d %d]', ...
                      num2str(o.funIdim), o.lambda, floor(o.evals/o.lambda)));
      end
      if strcmp(s{k}, 'model')
         disp(sprintf('  model for [f instance dim lam iter] = [%s %d %d]', ...
                      num2str(o.funIdim), o.lambda, floor(o.evals/o.lambda)));
      end
      if 11 < 3 && strcmp(s{k}, 'tolx')
         disp(sprintf('  tolx for [f instance dim lam iter] = [%s %d %d]', ...
                      num2str(o.funIdim), o.lambda, floor(o.evals/o.lambda)));
      end
      if strcmp(s{k}, 'equalfunvalhist') && length(s) == 1
         disp(sprintf('  equalfunvalhist ONLY for [f instance dim lam iter] = [%s %d %d]', ...
                      num2str(o.funIdim), o.lambda, floor(o.evals/o.lambda)));
      end
      if 11 < 3 && strfind(s{k}, 'stag')
         disp(sprintf('  stagnation for [f instance dim lam iter] = [%s %d %d]', ...
                      num2str(o.funIdim), o.lambda, floor(o.evals/o.lambda)));
      end
    end
  end
  if any(strcmp(o.stopflag, 'fitness'))
  else
    arfid(end+1,:) = o.funIdim;
    %disp(o);
    %pause
  end
  if o.funIdim(1) == 22 && o.funIdim(3) == 5
     arsel{end+1} = o;
  end
end
for i = 1:length(arsel)
   % disp(arsel{i});
end  
% disp(unique(stopflags)')

for sf = unique(stopflags)
  c = sum(strcmp(sf{1}, stopflags));
  disp(sprintf('  %s %d', sf{1}, c));
end