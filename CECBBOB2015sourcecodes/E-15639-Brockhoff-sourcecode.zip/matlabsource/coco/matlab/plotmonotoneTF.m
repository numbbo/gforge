x = logspace(-5, log10(6), 5000);
x = [-x(end:-1:1), x];
hold off;
plot(x, x, 'k-');
set(gca, 'fontsize', 24);
hold on; grid on
plot(x, x.^(1 + 0.1*sqrt(max(0,x))), 'g', 'linewidth', 2)
plot(x, x.^(1 + 0.2*sqrt(max(0,x))), 'g', 'linewidth', 2)
plot(x, x.^(1 + 0.5*sqrt(max(0,x))), 'g', 'linewidth', 2)
plot(x, monotoneTFosc(x), 'linewidth', 2)
axis([-6 6 -6 9])
disp(sprintf('  press key')); pause
print -dpng monotoneTF
axis([-1 1 -1 1])
disp(sprintf('  press key')); pause
print -dpng monotoneTFzoom1
axis(0.1*[-1 1 -1 1])
disp(sprintf('  press key')); pause
print -dpng monotoneTFzoom2
axis(0.01*[-1 1 -1 1])
print -dpng monotoneTFzoom3
