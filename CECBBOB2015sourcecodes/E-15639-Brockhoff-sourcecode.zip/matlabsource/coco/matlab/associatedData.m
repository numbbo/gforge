% Script to read xopt, fopt and rotation for each benchmark function and
% write in file for documentation.

% get benchmark handles
[handles,description] = benchmarks;

dim = [2,3,5,10,20,40];

for h = 108
    
    % get xopt
    [value,xopt] = feval(handles{h},'xopt',40);
    
    % loop over all dimensions
    for d = 1:length(dim)      
        [fopt(d),rotation{d}] = feval(handles{h},'linearTF',dim(d));
    end
    
    % create output file
    fname = strcat('BF_f',num2str(h),'_data.txt');
    [fid,message] = fopen(fname,'wt','native');
    
    % write header
    fprintf(fid,'This file contains the values xopt, fopt and the rotation matrices for\nthe benchmark function F%d.', h);
    fprintf(fid,'\n');
    fprintf(fid,'\nFunction ID and Description: \n%s\n',description{h});
    fprintf(fid,'\n');
    
    % write xopt 
    fprintf(fid,'Location of the optimum (xopt): \n');
    fprintf(fid,'%8.4f', xopt);
    fprintf(fid,'\n');
    
    % write fopt (given that fopt is the same for all dimensions)
    fprintf(fid,'\n');
    fprintf(fid,'Fitness at the optimum (fopt): %5.2f \n',fopt(1)); 
    fprintf(fid,'\n');
    
    % write rotation matrices
    fprintf(fid,'Rotation Matrices:\n');
    % check if rotation occurs
    if isempty(rotation{1}{1}) && isempty(rotation{1}{2})
        fprintf(fid,'Function is non-rotated.\n');
        continue    % go to next function
    else
        for d = 1:length(dim)
            str = repmat('%9.4f ',1,dim(d));
            str = strcat(str,'\n');
            fprintf(fid,'matrix linearTF for Dim %d:\n',dim(d));
            fprintf(fid,str,rotation{d}{1}');
            fprintf(fid,'\n');
            if ~isempty(rotation{d}{2})
                fprintf(fid,'matrix rotation for Dim %d:\n',dim(d));
                fprintf(fid,str,rotation{d}{2}');
                fprintf(fid,'\n');
            end
        end
    end
        
    % close file
    fclose(fid);
end