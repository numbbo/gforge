function f = montecarlo(fun, DIM, maxfevals)
% fun: function handle
% monte carlo random search 
% DEPRECATED: cf MY_OPTIMIZER.m

range = 8;
disp(['volume=' num2str(range) '^' num2str(DIM)]);

if nargin < 3
  maxfevals = 1e5*DIM;
end

popsize = 10*DIM; 

f = inf;
for i = 1 : 1 + maxfevals/popsize
  f = min(f, min(feval(fun, range*(rand(DIM, popsize)-0.5))));
end

