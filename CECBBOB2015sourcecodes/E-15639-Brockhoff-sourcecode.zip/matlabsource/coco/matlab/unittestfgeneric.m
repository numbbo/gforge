% unit test for fgeneric
% TODO: this is a stump and needs to be expanded in order to
%       serve as a reasonable test program.

%clear all;
%  dbstop in fgeneric at 271;
%  dbstop in fgeneric at 280;

fgeneric('finalize');
fgeneric('initialize', 5, 1, 'testfolder/test');
fgeneric('finalize');
fgeneric('initialize', 5, 1, 'testfolder/test');
fgeneric('initialize', 5, 1, 'testfolder/test');

rand('twister',0);
N=[5 5];

for itrial = 1:3
  for j = N
%      profile on;
    fgeneric('initialize', 5, itrial, 'testfolder/test');
    for i = 1:1e3
      fgeneric(rand(j,100));
    end
%      profile off;
  end
end

fgeneric('finalize');
fgeneric('finalize');
fgeneric('initialize', 5, 1, 'testfolder/test');
fgeneric(rand(j,100));
fgeneric(rand(10,100));
fgeneric(rand(j,100));
fgeneric('initialize', 5, 1, 'test');
fgeneric(rand(j,101));
fgeneric('initialize', 5, 1, 'testfolder/test');
fgeneric(rand(j,99));
fgeneric('finalize');
fgeneric('initialize', 5, 1, 'testfolder/test');
fgeneric(rand(j,99));
fgeneric('finalize');
fgeneric('initialize', 5, 1, '/users/dsa/ros/Desktop/coco/BBOB/demo/matlab/testfolder/test2/');
fgeneric(rand(j,99));
fgeneric('finalize');


