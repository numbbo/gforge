function [XMIN, FMIN, COUNTEVAL, STOPFLAG, OUT, BESTEVER] = ...
            runcmaeshtml(FUN, DIM, ftarget, maxfunevals)
% MY_OPTIMIZER(FUN, DIM, ftarget, maxfunevals)

  opts.restarts = 8;  % 2^7 == 128
  opts.maxiter = '100 + 300 * N * sqrt(N/popsize)';

  % ultimate termination option
  opts.maxfunevals = min(1e9 * DIM, maxfunevals); 

  % speed and output options
  opts.stopfitness = ftarget;
  opts.evalpar = 1;

  opts.savevar = 'off';
  opts.dispfinal = 0;
  opts.dispmod = 0;
  opts.logmod = 0;

  [XMIN, FMIN, COUNTEVAL, STOPFLAG, OUT, BESTEVER] = ...
    cmaeshtml(FUN, ['8*rand(' num2str(DIM) ', 1) - 4'], 2, opts);
  
  
