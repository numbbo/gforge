#! /usr/bin/env python 

filename = 'out-cmaes25.txt'
filename = 'out-cmaes24noiD20.txt'
filename = 'out-cmaes24noiD2-10.txt'
Dprinted = 10

lam = 0
res = {}
ressig = {}
for line in open(filename):
   if lam > 0:  # second line fxx ... after posize was read
      i = line.find('fbest-ftarget=')
      if float(line[i+14:].split(',')[0]) < 0:
         f = int(line.split()[0][1:])  # function number
         D = int(line.split()[2].split('-')[0]) # dimension
         k = (f,D)
         if res.has_key(k):
            res[k].append(lam)
            ressig[k].append(sig)
         else:
            res[k] = [lam]
            ressig[k] = [sig]

   lam = 0
   if line.find('popsize=') > 0:
      lam = int(line.split('popsize=')[1].split('-')[0])
      sig = float(line.split('sigfac=')[1].split(',')[0])

   res20 = {}
   for k,it in res.iteritems():
      if k[1] == Dprinted:
         res20[k[0]] = sorted(it)
   res20sig = {}
   for k,it in ressig.iteritems():
      if k[1] == Dprinted:
         res20sig[k[0]] = sorted(it)


for i,it in sorted(res20.iteritems()):
   if len(it) > 2:
      print i, '&', min(it), '&', it[-1 + (len(it) + 1) / 2], '&', max(it), '\\\\'
   else:
      print i, '&', '&', it[-1], '\\\\'

print 
for i,it in sorted(res20sig.iteritems()):
   if min(it) < 1:
      if len(it) > 2:
         print i, '&', 2*min(it), '&', 2*it[-1 + (len(it) + 1) / 2], '&', 2*max(it), '\\\\'
      else:
         print i, '&', '&', it[-1], '\\\\'

