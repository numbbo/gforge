% OBSOLETE: see exampleexperiment.m instead 
% runs an entire experiment for benchmarking MY_OPTIMIZER
% on the noise-free testbed. fgeneric.m and benchmarks.m 
% must be in the path of Matlab/Octave
% CAPITALIZATION indicates code adaptations to be made 

% addpath('PUT_PATH_TO_BBOB/code/matlab');  % should point to fgeneric.m etc.
homepath = '/host/Dokumente und Einstellungen/Niko/Eigene Dateien/COCOgforge/';
homepath = '/users/tao/hansen/my/COCO/gforge/'; 
addpath([homepath 'BBOB/code/matlab']); 
datapath = 'bbobdata-fminsearch09D10d'; 
opt.algName = 'fminsearch'; % used to differentiate experiments
opt.comments = '1e5*dim maxfunevals 1e4 multistarts tolx=1e-11 sig0=2 sig_xopt=0.01..0.1'; 
maxfunevals = '1e5 * dim';  % 1e4*dim takes overall one day for 5 trials 

t0 = clock;
rand('state', sum(100 * t0));

for dim = [10]  % small dimensions first, for CPU reasons
  for ifun = [1 2 5:24 3 4]  % benchmarks()  % benchmarksnoisy()
    for iinstance = [1 2 3 4 5]  % number of repetitions are prescribed
      fgeneric('initialize', ifun, iinstance, datapath, opt);

      [x, lau] = fminmultisearch(@fgeneric, dim, fgeneric('ftarget'), eval(maxfunevals));

      disp(sprintf(['  f%d in %d-D, trial %d, launches %d: FEs=%d,' ...
                    ' fbest-ftarget=%.4e, ftarget=%.4e, elapsed time [h]: %.2f'], ...
                   ifun, dim, iinstance, lau, ...
                   fgeneric('evaluations'), ...
                   fgeneric('fbest') - fgeneric('ftarget'), ...
                   fgeneric('ftarget'), ...
                   etime(clock, t0)/60/60));
      fgeneric('finalize');
    end
    disp(['      date and time: ' num2str(clock, ' %.0f')]);
  end
  disp(sprintf('---- dimension %d-D done ----', dim));
end
