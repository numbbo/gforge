function [XMIN, FMIN, COUNTEVAL, STOPFLAG, OUT, BESTEVER] = ...
            runcmaes(FUN, DIM, ftarget, maxfunevals)
% MY_OPTIMIZER(FUN, DIM, ftarget, maxfunevals)

% options are now default in the code
%  opts.restarts = 9;  % 2^9 == 512
%  opts.maxiter = '100 + 50 * (N+3)^2 / sqrt(popsize)';
%  opts.maxrestartfunevals = min(1e9 * DIM, maxfunevals); 
%  opt.tolupx = inf;


  % speed and output options
  opts.stopfitness = ftarget;
%  opts.evalpar = 1;

  if 11 < 3  % run silently
    opts.savevar = 'off'; 
    opts.dispfinal = 0;
    opts.dispmod = 0;
    opts.logmod = 0;
  end

  [XMIN, FMIN, COUNTEVAL, STOPFLAG, OUT, BESTEVER] = ...
    bipopcmaes(FUN, ['8*rand(' num2str(DIM) ', 1) - 4'], 2, opts);
  
  
