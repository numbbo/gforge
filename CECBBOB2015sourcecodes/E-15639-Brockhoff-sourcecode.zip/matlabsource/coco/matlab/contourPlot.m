function contourPlot(x,Z,fOpt,nContour,xOpt,flagAR,flagData)
    % generates and labels contour plot for BBOB
    
    % inputs:
    %         x - vector of values for square domain
    %         Z - fitness values in the domain
    %         fOpt - function value at the optimum 
    %         nCounter - number of contour lines
    %         xOpt - optimum in the surface
    %         flagAR - sets if arrow to optimum is shown, string, value
    %                  should be set to to 'show' for drawing the arrow
    %         flagData - determines if input to contour are logarithmic
    %                    data (flagData = 'log') or not
    
    % which type of data (log or normal should be displayed)
    if strcmp(flagData,'log')
        Y = log10(Z-fOpt+1e-9);
    else
        Y = Z;
    end

    % draw contour plot
    figure('Position',[1 700 700 700])
    contour(x,x,Y,nContour,'LineWidth',3);
    axis square
    set(gca,'FontSize',15)
    xlabel('x_1','FontSize',20)
    ylabel('x_2','FontSize',20)
    grid
    set(gcf,'PaperPositionMode','auto','PaperType','A4')
    
    if strcmp(flagAR,'show') == 1
        % draw arrow to indicate optimum
        if xOpt(2) - 1 > -4
            arrowX=[0 0 -.1 NaN 0.1 0] + xOpt(1);
            arrowY=[0 1 0.8 NaN 0.8 1] + xOpt(2) - 1;
        else
            arrowX=[0 0 -.1 NaN 0.1 0] + xOpt(1);
            arrowY=-[0 1 0.8 NaN 0.8 1] + xOpt(2) + 1;
        end
        line(arrowX, arrowY, 'LineWidth',3, ...
             'Color','black','LineStyle','-')
    end
end