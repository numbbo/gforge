% runs an entire experiment for benchmarking MY_OPTIMIZER
% on the noise-free testbed. fgeneric.m and benchmarks.m
% must be in the path of Matlab/Octave
% CAPITALIZATION indicates code adaptations to be made

homepath = '/host/Dokumente und Einstellungen/Niko/Eigene Dateien/';
homepath = '/users/tao/hansen/my/'; 
addpath([homepath 'workinghtml']); 
addpath([homepath 'COCO/gforge/BBOB/code/matlab']); 
datapath = 'bbobdata-cmaes-bipop-verification';  % different folder for each experiment
opt.algName = 'bipopcmaes';
opt.comments = 'bbob-2009 parameters are default now ';
maxfunevals = '1e7*dim';  % not in use 1e7==20h on pc5

more off;  % in octave pagination is on by default

t0 = clock; 
rand('state', sum(100 * t0));

arout = {};
funs = [1 2 5:24 3 4];
for dim = [2,3,5,10,20,40]  % small dimensions first, for CPU reasons
  for ifun = funs
    for iinstance = [1 1 1 2 2 2 3 3 3 4 4 4 5 5 5]  % first 5 function instances, three times 

      fgeneric('initialize', ifun, iinstance, datapath, opt); 

      [XMIN, FMIN, COUNTEVAL, STOPFLAG, OUT, BESTEVER] = ...
        runcmaesverification('fgeneric', dim, fgeneric('ftarget'), eval(maxfunevals));
      OUT.funIdim = [ifun iinstance dim];
      arout{end+1} = OUT;

      disp(sprintf(['  f%d in %d-D, instance %d: FEs=%ld,' ...
                    ' fbest-ftarget=%.4e, elapsed time [h]: %.2f'], ...
                   ifun, dim, iinstance, ...
                   fgeneric('evaluations'), ...
                   fgeneric('fbest') - fgeneric('ftarget'), ...
                   etime(clock, t0)/60/60));
      fgeneric('finalize');
    end
    % disp(['      date and time: ' num2str(clock, ' %.0f')]);
  end
  disp(sprintf('---- dimension %d-D done ----', dim));
  save(['variables-' datapath '.mat']);
end
quit
