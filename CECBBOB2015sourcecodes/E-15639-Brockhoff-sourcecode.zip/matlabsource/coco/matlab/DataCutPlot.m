function  [xValues,fValues,xOpt] = DataCutPlot(DIM,xMin,nPoints,fitness,...
                                          xMaxLogLog,xMaxOther)
% generates data for the section graphs

% inputs: DIM  - search space dimension
%         xMin - smallest value for logspaced vector (1exMin)
%         nPoints - number of points for graphs
%         fitness - handle to current benchmark function
%         xMaxLogLog - largest value for logspaced Vector (coordinate
%         value)
%         xMaxOther - determines xMin and xMax for semilog and normalized
%         plots
%         
% outputs: xValues - [3 x nPoints] matrix
%                     1st row contains x-values of loglog - plot for
%                     section along x1-axis.
%                     2nd row contains x-values of loglog - plot for
%                     section along x2-axis.
%                     3rd row contains x-values of normal plot and
%                     semilog-plot. 
%          fValues - [12 x nPoints] matrix
%                     1st row contains y-values of loglog-plot for section
%                     along x1-axis
%                     2nd row contains y-values of loglog-plot for section
%                     along -x1-axis
%                     3rd row contains y-values of loglog-plot for section
%                     along x2-axis
%                     4th row contains y-values of loglog-plot for section
%                     along -x2-axis
%                     5th row contains y-values of loglog-plot for section
%                     along ones-axis
%                     6th row contains y-values of loglog-plot for section
%                     along -ones-axis
%                     7th row contains y-values of semilog-plot for section
%                     along x1-axis
%                     8th row contains y-values of normalized plot for section
%                     along x1-axis
%                     9th row contains y-values of semilog-plot for section
%                     along x2-axis
%                     10th row contains y-values of normalized plot for section
%                     along x2-axis
%                     11th row contains y-values of semilog-plot for section
%                     along ones-axis
%                     12th row contains y-values of normalized plot for section
%                     along ones-axis
%          xOpt - location of the optimum for plotting the domain border

    % determine fOpt and xOpt
    [fOpt,xOpt] = fitness('xopt',DIM);
    xOpt = xOpt(1:DIM);
    
    % log-log data
    for i = 1:2
        if (xOpt(i) == 0)
            xMax = xMaxLogLog;           
        else
            xMax = abs(-sign(xOpt(i))*xMaxLogLog - xOpt(i));           
        end
        xValues(i,:) = logspace(xMin,log10(xMax),nPoints);
    end
    
    fValues(1,:) = fitness(xOpt*ones(1,nPoints) + [xValues(1,:);zeros(DIM-1,nPoints)]) - fOpt;
    fValues(2,:) = fitness(xOpt*ones(1,nPoints) - [xValues(1,:);zeros(DIM-1,nPoints)]) - fOpt;
    fValues(3,:) = fitness(xOpt*ones(1,nPoints) + [zeros(1,nPoints);xValues(2,:);zeros(DIM-2,nPoints)]) - fOpt;
    fValues(4,:) = fitness(xOpt*ones(1,nPoints) - [zeros(1,nPoints);xValues(2,:);zeros(DIM-2,nPoints)]) - fOpt;
    fValues(5,:) = fitness(xOpt*ones(1,nPoints) + repmat(xValues(2,:),DIM,1)) - fOpt;
    fValues(6,:) = fitness(xOpt*ones(1,nPoints) - repmat(xValues(2,:),DIM,1)) - fOpt;
    
    % Remark: For ones(DIM,nPoints) it is possible that data outside the
    %         domian will be reached. But this is not really visible in the
    %         log-log plot.

    % normalized and semilog data
    xValues(3,:) = linspace(-xMaxOther,xMaxOther,nPoints);
    xValues(4,:) = linspace(-1.2*xMaxOther,1.2*xMaxOther,nPoints);
    
    fValues(7,:) = fitness([zeros(1,nPoints);repmat(xOpt(2:DIM),1,nPoints)] + [xValues(4,:);zeros(DIM-1,nPoints)]) - fOpt;
    fValues(8,:) = fitness([zeros(1,nPoints);repmat(xOpt(2:DIM),1,nPoints)] + [xValues(3,:);zeros(DIM-1,nPoints)]) - fOpt;
    fValues(8,:) = fValues(8,:)/max(fValues(8,:));
    fValues(9,:) = fitness([repmat(xOpt(1),1,nPoints);zeros(1,nPoints);repmat(xOpt(3:DIM),1,nPoints)] + [zeros(1,nPoints);xValues(4,:);zeros(DIM-2,nPoints)]) - fOpt;
    fValues(10,:) = fitness([repmat(xOpt(1),1,nPoints);zeros(1,nPoints);repmat(xOpt(3:DIM),1,nPoints)] + [zeros(1,nPoints);xValues(3,:);zeros(DIM-2,nPoints)]) - fOpt;
    fValues(10,:) = fValues(10,:)/max(fValues(10,:));
    fValues(11,:) = fitness(repmat(xOpt,1,nPoints) + repmat(xValues(4,:),DIM,1)) - fOpt;
    fValues(12,:) = fitness(repmat(xOpt,1,nPoints) + repmat(xValues(3,:),DIM,1)) - fOpt;
    fValues(12,:) = fValues(12,:)/max(fValues(12,:));
end