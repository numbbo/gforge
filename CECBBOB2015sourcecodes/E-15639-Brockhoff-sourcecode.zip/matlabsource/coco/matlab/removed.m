funcion removed

function g = monotoneTF2(f)
% maps [0,inf] to [0,inf] 
  idx = (f > 0); 
  f(idx) = f(idx).^abs(log(f(idx)));
end

function g = monotoneTF1(f)
% maps [-inf,inf] to [-inf,inf], symmetrical about zero
   a = 0.1;
   signf = sign(f);
   idx0 = (f == 0);
   f(idx0) = NaN;  % prevent error for log
   g = log(abs(f))/a;
   g = signf .* exp(g + 0.49*(sin(g) + sin(0.79*g))).^a;
   g(idx0) = 0;  % restore NaN
end

function g = monotoneTF1neg(f)
% maps [-inf,inf] to [-inf,inf], identity for larger zero
   a = 0.1;
   g = f;
   idx = (f < 0);
   g(idx) = log(-f(idx))/a;
   g(idx) = -exp(g(idx) + 0.49*(sin(0.55*g(idx)) + sin(0.31*g(idx)))).^a;
end

%%%-------------------------------------------------------------%%%
function [Fval, Ftrue] = f22(x, DIM)
% Gallagher with 101 Gaussian peaks, condition up to 1000
% CAVE: the difficulty might significantly depend on the
%       random realization for the location of optima. 
% last change: 09/01/26
  persistent Fopt Xopt scales linearTF rotation Cov Xlocal peakvalues
  persistent lastSize arrXopt arrScales arrExpo 

  funcID = 22; 
  maxcondition = 1000;  % for linear transformation
  fitvalues = [1.1, 9.1];    % range for raw values, 10 is optimal
  nhighpeaks = 101;  
  rseed = funcID; 
  
  %----- CHECK INPUT -----
  if ischar(x) % return Fopt Xopt or linearTF on string argument
    flginputischar = 1;
    strinput = x;
    if nargin < 2
      DIM = 2;
    end
    x = ones(DIM,1);  % setting all persistent variables
  else
    flginputischar = 0;
  end
  % from here on x is assumed a numeric variable
  [DIM, POPSI] = size(x);  % dimension, pop-size (number of solution vectors)
  if DIM == 1 
    error('1-D input is not supported');
  end
  
  %----- INITIALIZATION -----
  if isempty(Fopt)
    Fopt =1* min(1000, max(-1000, round(100*100*gauss(1,rseed)/gauss(1,rseed+1))/100));
  end 
  Fadd = Fopt;  % value to be added on the "raw" function value
  % DIM-dependent initialization
  if isempty(lastSize) || lastSize.DIM ~= DIM  
    % compute covariance matrices
    arrCondition = maxcondition.^linspace(0,1,nhighpeaks-1);
    [ignore, idx] = sort(unif(nhighpeaks-1, rseed));  % random permutation
    arrCondition = [sqrt(maxcondition) arrCondition(idx)];
    Cov = {}; 
    for i = 1:nhighpeaks  % generation of cov matrices 
      s = arrCondition(i).^linspace(-0.5, 0.5, DIM); 
      Cov{i} = computeRotation(rseed+1e3*(i-1), DIM); 
      Cov{i} = Cov{i} * diag(s) * Cov{i}'; % this is inverse Cov
      if s(1) == s(end)  
        Cov{i} = 1;  % true for the first entry 
      end 
    end
    % compute peak values, 10 is global optimum
    peakvalues = [10 linspace(fitvalues(1), fitvalues(2), nhighpeaks-1)]; 
  end
  % DIM- and POPSI-dependent initializations of DIMxPOPSI matrices
  if isempty(lastSize) || lastSize.DIM ~= DIM || lastSize.POPSI ~= POPSI
    lastSize.POPSI = POPSI; 
    lastSize.DIM = DIM; 
    Xlocal = reshape(10*unif(DIM*nhighpeaks, rseed)-5, ...
                          DIM, nhighpeaks); 
    % global optimum not too close to boundary
    Xlocal(:,1) = 0.8 * Xlocal(:,1); 
    Xopt = Xlocal(:,1);
  end

  %----- BOUNDARY HANDLING -----
  xoutside = max(0, abs(x) - 5) .* sign(x); 
  Fpen = 1 * sum(xoutside.^2, 1);  % penalty
  Fadd = Fadd + Fpen; 

  %----- TRANSFORMATION IN SEARCH SPACE -----

  %----- COMPUTATION core -----
  fac = -0.5/DIM; % ??xopt + alpha*ones versus alpha becomes invariant like this 
  f = NaN*ones(nhighpeaks,POPSI); 
  for i = 1:nhighpeaks  % CAVE: POPSI = 1e4 gets out of memory
    xx = (x - repmat(Xlocal(:,i), 1, POPSI)); % repmat could be done once
    f(i,:) = peakvalues(i) * exp(fac*(sum(xx.*(Cov{i}*xx), 1))); 
  end
  % f is in [0,10], 10 is best
  Ftrue = monotoneTFosc(10 - max(f, [], 1)).^2;  
  Fval = Ftrue;  % without noise

  %----- NOISE -----

  %----- FINALIZE -----
  Ftrue = Ftrue + Fadd;
  Fval = Fval + Fadd;

  %----- RETURN INFO ----- 
  if flginputischar  
    if strcmpi(strinput, 'xopt')
      Fval = Fopt;
      Ftrue = Xopt;
    elseif strcmpi(strinput, 'linearTF')
      Fval = Fopt;
      Ftrue = {};
      Ftrue{1} = linearTF; 
      Ftrue{2} = rotation; 
    else  % if strcmpi(strinput, 'info')
      Ftrue = benchmarkinfos(funcID); 
      Fval = Fopt;
    end
  end
end % function

function g = monotoneTF1neg(f)
% maps [-inf,inf] to [-inf,inf], identity for larger zero
   a = 0.1;
   g = f;
   idx = (f < 0);
   g(idx) = log(-f(idx))/a;
   g(idx) = -exp(g(idx) + 0.49*(sin(0.55*g(idx)) + sin(0.31*g(idx)))).^a;
end

function g = monotoneTF2(f)
% maps [0,inf] to [0,inf] 
  idx = (f > 0); 
  f(idx) = f(idx).^abs(log(f(idx)));
end

function g = monotoneTF1(f)
% maps [-inf,inf] to [-inf,inf], symmetrical about zero
   a = 0.1;
   signf = sign(f);
   idx0 = (f == 0);
   f(idx0) = NaN;  % prevent error for log
   g = log(abs(f))/a;
   g = signf .* exp(g + 0.49*(sin(g) + sin(0.79*g))).^a;
   g(idx0) = 0;  % restore NaN
end

function g = monotoneTF1pos(f)
% maps [-inf,inf] to [-inf,inf], identity for smaller zero
   a = 0.1;
   g = f;
   idx = (f > 0);
   g(idx) = log(f(idx))/a;
   g(idx) = exp(g(idx) + 0.49*(sin(g(idx)) + sin(0.79*g(idx)))).^a;
end

%Bi-Rastrigin, old range:
  % TODO: should be dimension dependent
%  s = 0.2;  % 30% in 10-D, scale [0.2,1], smaller is more difficult 
  % s = 0.7;  % 30% in 30-D for local search 
  % s = DIM / (DIM + 1e3/DIM);    %...+1e3/DIM
%                             2:38/100
%                             4:25/100
%  2: 50/100                 10: 14/100
%  4: 25/100                 20: 17/100
%                            40: 19/100
% 10: 0.2 = DIM/(DIM+40) = D/(D+400/D)
% 20: 0.5 = DIM/(DIM+20) = D/(D+400/D)
% 30: 0.7 = DIM/(DIM+13) = D/(D+400/D)

% Gallagher with 99 Gaussian peaks, condition up to 1000
% CAVE: the difficulty might significantly depend on the
%       random realization for the location of optima. 
% last change: 08/11/21
  persistent Fopt Xopt scales rotation Cov Xlocal peakvalues
  persistent lastSize arrXopt arrExpo volume

  funcID = 21; 
  maxcondition = 1000; % maximal condition number for cov matrices
  nhighpeaks = 99;  % TODO: use 49 for performance reason? 
  
  %----- RETURN INFO ----- 
  if ischar(x) % return Fopt Xopt or linearTF on string argument
    if nargin < 2
      DIM = 2;
    end
    feval(['f' num2str(funcID)], ones(DIM, 1));
    Fval = Fopt;
    if strcmpi(x, 'xopt')
      Ftrue = Xopt;
    elseif strcmpi(x, 'linearTF')
      Ftrue = {};
      Ftrue{1} = linearTF; 
      Ftrue{2} = rotation; 
    else
      Ftrue = benchmarks('', funcID); 
    end
    return;
  end

  %----- CHECK INPUT -----
  % from here on x is assumed a numeric variable
  [DIM, POPSI] = size(x);  % dimension, pop-size (number of solution vectors)
  if DIM == 1 
    error('1-D input is not supported');
  end
  
  %----- INITIALIZATION -----
  if isempty(Fopt)
    Fopt =0* (round(100*100*gauss(1,funcID)/gauss(1,funcID+1))/100);
  end 
  Fadd = Fopt;  % value to be added on the "raw" function value
  % DIM-dependent initialization
  if isempty(lastSize) || lastSize.DIM ~= DIM  
    % rotation = computeRotation(funcID-1, DIM); 
    % compute covariance matrices
    arrCondition = maxcondition.^linspace(0,1,nhighpeaks-1);
    [ignore, idx] = sort(unif(nhighpeaks-1, funcID));  % random permutation
    arrCondition = [sqrt(maxcondition) arrCondition(idx)];
    Cov = {}; 
    for i = 1:nhighpeaks  % generation of cov matrices 
      s = arrCondition(i).^linspace(-0.5, 0.5, DIM); 
      Cov{i} = computeRotation(funcID+1e3*(i-1), DIM); 
      Cov{i} = Cov{i} * diag(s) * Cov{i}'; % this is inverse Cov
      if s(1) == s(end)  
        Cov{i} = 1;  % true for the first entry 
      end 
    end
    % compute peak values, 10 is global optimum
    peakvalues = 10 - [0 linspace(1, 5, nhighpeaks-1)]; 
  end
  % DIM- and POPSI-dependent initializations of DIMxPOPSI matrices
  if isempty(lastSize) || lastSize.DIM ~= DIM || lastSize.POPSI ~= POPSI
    lastSize.POPSI = POPSI; 
    lastSize.DIM = DIM; 
    Xlocal = reshape(10*unif(DIM*nhighpeaks, funcID)-5, ...
                          DIM, nhighpeaks); 
    % global optimum not too close to boundary
    Xlocal(:,1) = 0.8 * Xlocal(:,1); 
    Xopt = Xlocal(:,1);
  end

  %----- BOUNDARY HANDLING -----
  penexpo = 1;  % 0.5 or 1
  xoutside = max(0, abs(x) - 5) .* sign(x); 
  Fpen = 1e-0 * sum(xoutside.^2, 1).^penexpo;  % penalty
  % x(xoutside~=0) = x(xoutside~=0) - xoutside(xoutside~=0);  % into [-5, 5]
  Fadd = Fadd + Fpen; 

  %----- TRANSFORMATION IN SEARCH SPACE -----

  %----- COMPUTATION -----
  fac = -0.5/DIM; % ??xopt + alpha*ones versus alpha becomes invariant like this 
  f = NaN*ones(nhighpeaks,POPSI); 
  for i = 1:nhighpeaks  % CAVE: POPSI=1e4 gets out of memory
    xx = (x - repmat(Xlocal(:,i), 1, POPSI)); % repmat could be done once
    f(i,:) = peakvalues(i) * exp(fac*(sum(xx.*(Cov{i}*xx), 1))); 
  end
    
  % f is in [0,10], 10 is best
  % Ftrue = 1e4 - 1e3 * max(f, [], 1); 
  % Ftrue = 1 - log10(max(f, [], 1)+1e-99);  % does not effect the optimal value
  Ftrue = 1 * (10 - max(f, [], 1)); 
  Fval = Ftrue;  % without noise

  %----- FINALIZE -----
  Ftrue = Ftrue + Fadd;
  Fval = Fval + Fadd;

%%%-------------------------------------------------------------%%%
function [Fval, Ftrue] = f21(x, DIM)
% Gallagher with 99 Gaussian peaks, condition up to 100
% CAVE: the difficulty might significantly depend on the
%       random realization for the location of optima. 
% last change: 08/11/21
  persistent Fopt Xopt scales rotation Cov Xlocal peakvalues
  persistent lastSize arrXopt arrExpo volume

  funcID = 21; 
  maxcondition = 100; % maximal condition number for cov matrices
  nhighpeaks = 99;  % TODO: use 49 for performance reason? 
  
  %----- RETURN INFO ----- 
  if ischar(x) % return Fopt Xopt or linearTF on string argument
    if nargin < 2
      DIM = 2;
    end
    feval(['f' num2str(funcID)], ones(DIM, 1));
    Fval = Fopt;
    if strcmpi(x, 'xopt')
      Ftrue = Xopt;
    elseif strcmpi(x, 'linearTF')
      Ftrue = {};
      Ftrue{1} = linearTF; 
      Ftrue{2} = rotation; 
    else
      Ftrue = benchmarks('', funcID); 
    end
    return;
  end

  %----- CHECK INPUT -----
  % from here on x is assumed a numeric variable
  [DIM, POPSI] = size(x);  % dimension, pop-size (number of solution vectors)
  if DIM == 1 
    error('1-D input is not supported');
  end
  
  %----- INITIALIZATION -----
  if isempty(Fopt)
    Fopt =0* (round(100*100*gauss(1,funcID)/gauss(1,funcID+1))/100);
  end 
  Fadd = Fopt;  % value to be added on the "raw" function value
  % DIM-dependent initialization
  % condition 1000 leads to a flat fitness
  nlowpeaks = ceil(1*nhighpeaks);  % TODO: not in use, remove! 
  if isempty(lastSize) || lastSize.DIM ~= DIM  
    % compute and covariance matrices for high local minima 
    rotation = computeRotation(funcID-1, DIM); 
    Cov = {}; 
    arrCondition = maxcondition.^linspace(0,1,nhighpeaks-1);
    [ignore, idx] = sort(unif(nhighpeaks-1, funcID));  % random permutation
    arrCondition = [sqrt(maxcondition) arrCondition(idx)];
    % TODO: clean up
    % arrCondition(3:2:end) = 1;  % might save 30% CPU time
    % disp(arrCondition')
    for i = 1:nhighpeaks % generation of cov matrices 
      s = sqrt(arrCondition(i)).^linspace(-1, 1, DIM); 
      Cov{i} = computeRotation(funcID+1e3*(i-1), DIM); 
      Cov{i} = Cov{i} * diag(s) * Cov{i}'; % this is inverse Cov
      if s(1) == s(end)
        Cov{i} = 1;
      end
    end
    % compute peak values
    % 100 peaks: 6 works, 4 still, 2 does not
    peakvalues.high = 10 - [0 linspace(1, 5, nhighpeaks-1)]; 
    % f in [0.1,5]
    peakvalues.low = 10 - linspace(9, 9, nlowpeaks);  % 5 works, 7 fails
  end
  % DIM- and POPSI-dependent initializations of DIMxPOPSI matrices
  if isempty(lastSize) || lastSize.DIM ~= DIM || lastSize.POPSI ~= POPSI
    lastSize.POPSI = POPSI; 
    lastSize.DIM = DIM; 
    Xlocal.low = reshape(10*unif(DIM*nlowpeaks, funcID+nhighpeaks) - 5, ...
                         DIM, nlowpeaks); 
    Xlocal.high = reshape(10*unif(DIM*nhighpeaks, funcID)-5, ...
                          DIM, nhighpeaks); 
    % global optimum not too close to boundary
    Xlocal.high(:,1) = 0.8 * Xlocal.high(:,1); 
    Xopt = Xlocal.high(:,1);
    arrXopt = repmat(Xopt, 1, POPSI); 
    beta = 0.02; 
    arrExpo = repmat(beta * linspace(0, 1, DIM)', 1, POPSI); 
  end

  %----- BOUNDARY HANDLING -----
  penexpo = 1;  % 0.5 or 1
  xoutside = max(0, abs(x) - 5) .* sign(x); 
  Fpen = 1e-2 * sum(xoutside.^2, 1).^penexpo;  % penalty
  % x(xoutside~=0) = x(xoutside~=0) - xoutside(xoutside~=0);  % into [-5, 5]
  Fadd = Fadd + Fpen; 

  %----- TRANSFORMATION IN SEARCH SPACE -----
  if 11 < 3  % non-linear asymmetric transformation
    % TODO: yes or no? Seems to make it (much) easier!!
    % x = rotation * x; 
    x = rotation * (x - arrXopt); 
    % idx = x>0;
    % x(idx) = x(idx).^(1 + arrExpo(idx) .* (x(idx)));  % smooth
    x = sign(x) .* abs(x).^(1 + arrExpo .* (abs(x)));  % smooth
    % x(idx) = x(idx).^(1 + arrExpo(idx));  % non-smooth 
    x = rotation' * x + arrXopt;  % back-rotation
    % x = rotation' * x; 
  end

  %----- COMPUTATION -----
  fac = -0.5/DIM; % xopt + alpha*ones versus alpha becomes invariant like this 
  f = NaN*ones(nhighpeaks+nlowpeaks,POPSI); 
  for i = 1:nhighpeaks  % CAVE: POPSI=1e4 gets out of memory
    xx = (x - repmat(Xlocal.high(:,i), 1, POPSI)); % repmat could be done once
    f(i,:) = peakvalues.high(i) * exp(fac*(sum(xx.*(Cov{i}*xx), 1))); 
  end
  for i = 1:0*POPSI  % compute lowpeak values
    xx = repmat(x(:,i), 1, nlowpeaks) - Xlocal.low; 
    f(nhighpeaks+(1:nlowpeaks), i) = peakvalues.low .* ...
        exp(fac*(sum(xx.^2, 1))); 
%        exp(fac*condition*(sum(xx.^2, 1))); 
%        exp(fac*median(volume)^-1*(sum(xx.^2, 1))); 
  end
  % f is in [0,10]
  % Ftrue = 1e4 - 1e3 * max(f, [], 1); 
  % Ftrue = 1 - log10(max(f, [], 1)+1e-99);  % does not effect the optimal value
  Ftrue = 1 * (10 - max(f, [], 1)); 
  Fval = Ftrue;  % without noise

  %----- FINALIZE -----
  Ftrue = Ftrue + Fadd;
  Fval = Fval + Fadd;
end % function


      if i == 1
        % 80% of given condition? 
        s = condition.^(1*unif(DIM, funcID)*(DIM+1)/(DIM-1)); 
        s([1,end]) = [1 condition];
        s(1) = 1;
        volume(1) = exp(mean(-log(s))); 
      else
        s = condition.^(unif(DIM, funcID+1e3*(i-1))*(DIM+1)/(DIM-1)); 
        s([1,end]) = [1 condition];
        volume(i) = exp(mean(-log(s))); 
      end

      if i == 1
        peakvalues.high = 10; 
      elseif i <= nveryhighpeaks
        % f in [9,10]
        peakvalues.high(i) = 9 + linspace(1, funcID+i-1);
      else
        % f in [5,9]
        peakvalues.high(i) = 5 + 4*unif(1, funcID+i-1); 
      end
