% these are stumps for convenient editing and copy and paste purpose

function res = functionbodies()
  % returns a random Fopt value
  res = floor(100*2000*rand(1,1))/100 - 1000 - 1e-8;

    scales{DIM} = sqrt(condition).^(max(0,2-DIM):1./max(1,DIM-1)):1)'; 


% Gallagher & Yuan

  % parallelized over population
  f = []; 
  for i = 1:npeaks
    xx = (x-repmat(Xlocal(:,i), 1, POPSI)); % repmat can be done once
    f(i,:) = peakvalues(i) * exp(-0.5*(xx'*Cov{DIM}*xx)); 
    % TODO: or exp(-0.5*(xx'*Cov{DIM}*xx)/DIM) ? 
  end
  Ftrue = 1e4 - 1e3 * max(f, [], 1); 
  
  % parallelized over npeaks, does not work with different Covs
  f = []; 
  for k = 1:POPSI
    xx = repmat(x(:,k), 1, npeaks) - Xlocal; 
    f(:,k) = (peakvalues .* exp(-0.5*sum(xx.*(Cov{DIM}*xx), 1)))'; 
    % TODO: or exp(-0.5*(xx'*Cov{DIM}*xx)/DIM) ? 
  end
  Ftrue = 1e4 - 1e3 * max(f, [], 1); 

% weierstrass, condition 10, one implementation
N = size(x,1);
a=0.5;
b=3;
K=[0:20];
f=0;
for i=1:N
  f = f + sum(exp(K.*log(a)).*(cos(2*pi*exp(K.*log(b)).*(x(i)+0.5))-cos(pi*exp(K.*log(b)))));
end; 

% CEC2005 matlab implementation, seems MUCH harder to solve:
function [f]=fweierstrass(x)
[ps,D]=size(x);
x=x+0.5;
a = 0.5;
b = 3;
kmax = 20;
c1(1:kmax+1) = a.^(0:kmax);
c2(1:kmax+1) = 2*pi*b.^(0:kmax);
f=0;
c=-w(0.5,c1,c2);
for i=1:D
f=f+w(x(:,i)',c1,c2);
end
f=f+c*D;

function y = w(x,c1,c2)
y = zeros(length(x),1);
for k = 1:length(x) % looks like a bug as length(x) == max(size(x))
	y(k) = sum(c1 .* cos(c2.*x(:,k)));
end


%%%-------------------------------------------------------------%%%
function [Fval, Ftrue] = f104(x)
% ellipsoid with gauss noise, condition 1e3
  persistent funcID rotations Xopt Fopt paralpha parbeta
  [DIM, POPSI] = size(x);  % dimension, pop-size (number of solution vectors)

  % intialize
  if length(rotations) < DIM || isempty(rotations{DIM})
    % function ID used as seed for rotation
    funcID = 102;
    paralpha = 1e3; % condition number
    parbeta = 1; % function specific parameter
    Fopt =0* -98.030000010;
    rotations{DIM} = computeRotation(funcID, DIM);
    % might be function specific
    Xopt = computeXopt(funcID, DIM);
  end
  % return optimal function value
  if isstr(x)
    Fval = Fopt;
    Ftrue = funcID;
    if strcmpi(x, 'xopt')
      if length(Xopt) <= 1  % xopt not yet generated
        warning('to receive xopt call function first with vector argument');
      end
      Ftrue = Xopt;
    end
    return;
  elseif DIM == 1
    warning('1-D input is not necessarily supported');
  end

  Fadd = Fopt; % value to be added on the "raw" function value

  % compute boundary penalty
  idx_out_of_bounds = abs(x) > 5;
  Fpen = 1e4 * sum(idx_out_of_bounds .* (abs(x) - 5).^2, 1);
  x(idx_out_of_bounds) = sign(x(idx_out_of_bounds)) * 5;
  Fadd = Fopt + Fpen;

  % transformation in x-space, might be function specific
  x = rotations{DIM}*x - repmat(Xopt(1:DIM), 1, POPSI);

  % compute function value
  Ftrue = paralpha.^(0:1./(DIM-1):1) * x.^2;
  Fval = Ftrue .* exp(parbeta*randn(1,POPSI)); %%% with noise

  % finalize function values
  % treat noisy case and Ftarget
  TOL = 1e-8;
  if Ftrue < TOL % Ftarget was reached
    Fval = Ftrue; % Fval < Ftarget
  elseif Fval < 1.01*TOL
    Fval = min(Ftrue, 1.01*TOL);
  end
  Ftrue = Ftrue + Fadd;
  Fval = Fval + Fadd;
end

%%%-------------------------------------------------------------%%%
function [Fval, Ftrue] = f110(x)
% rosenbrock with uniform noise
  persistent funcID rotations Xopt Fopt paralpha
  [DIM, POPSI] = size(x);  % dimension, pop-size (number of solution vectors)

  % intialize
  if length(rotations) < DIM || isempty(rotations{DIM})
    % function ID used as seed for rotation
    funcID = 110;
    paralpha = 0.49 + 1./DIM; % function specific parameter
    Fopt =0* -9.080000010;
    rotations{DIM} = computeRotation(funcID, DIM);
    Xopt{DIM} = rotations{DIM}'*ones(DIM,1) + 0.5;
  end
  % return optimal function value
  if isstr(x)
    Fval = Fopt;
    Ftrue = funcID;
    if strcmpi(x, 'xopt')
      if length(Xopt) <= 1  % xopt not yet generated
        warning('to receive xopt call function first with vector argument');
      end
      Ftrue = Xopt;
    end
    return;
  elseif DIM == 1
    warning('1-D input is not necessarily supported');
  end

  Fadd = Fopt; % value to be added on the "raw" function value

  % compute boundary penalty
  idx_out_of_bounds = abs(x) > 5;
  Fpen = 1*1e4 * sum(idx_out_of_bounds .* (abs(x) - 5).^2, 1);
  x(idx_out_of_bounds) = sign(x(idx_out_of_bounds)) * 5;
  Fadd = Fopt + Fpen;

  % transformation in x-space
  x = x * (8. / sqrt(DIM));
  x = rotations{DIM} * (x - 0.5);

  % compute function value
  Ftrue = 1e2*sum((x(1:end-1,:).^2 - x(2:end,:)).^2,1) + sum((x(1:end-1,:)-1).^2,1);

  % compute noisy f-value
  Fval = rand(1,POPSI) .* Ftrue .* max(1, (10^9./Ftrue).^(paralpha*rand(1,POPSI)));

  % finalize function values
  % treat noisy case and Ftarget
  TOL = 1e-8;
  if Ftrue < TOL % Ftarget was reached
    Fval = Ftrue; % Fval < Ftarget
  elseif Fval < 1.01*TOL
    Fval = min(Ftrue, 1.01*TOL);
  end
  Ftrue = Ftrue + Fadd;
  Fval = Fval + Fadd;
end




function f=fstepsphere(x, scal)
  if nargin < 2 || isempty (scal)
    scal = 1e0;
  end
  N = size(x,1);
  f=1e-11+sum(scal.^((0:N-1)/(N-1))*floor(x+0.5).^2);
  f=1e-11+sum(floor(scal.^((0:N-1)/(N-1))'.*x+0.5).^2);

  % step-ellipsoid, condition 100
  Ftrue = 1e-11 + paralpha * sum(round(x).^2, 1); 

%  f=1e-11+sum(floor(x+0.5).^2);

function Fval = cauchynoise(x)
  % sample Cauchy with median 1e3*paralpha and with p=0.2, zero otherwise
  Fval = Ftrue + paralpha * (1e3 + (rand(1,POPSI) < 0.2) .* randn(1,POPSI) ./ RN); 

function [F,Fopt] = sphere(x)
  funcID = 1;
  Ftrue = sum(x.^2, 1);

function [FF, F] = elliSeparable(x)
  F = monotonTF1(10.^(6 * (0:1./(DIM-1):1)) * x.^2); 

function [Fval, Fopt, Ftrue] = rosen(x)
    funcID = 8;  % used as seed
    Xopt{DIM} = rotations{DIM}'*ones(DIM,1) + 0.5; 


  % transformation in x-space
  % rot' * ones and rot' * zeros should be in [-4,4]
  % therefore, scaling such that sqrt(DIM) <= 8 
  x = x * (8. / sqrt(DIM)); 
  x = rotations{DIM} * (x - 0.5); 

  % compute function value
  Ftrue = 1e2*sum((x(1:end-1,:).^2 - x(2:end,:)).^2,1) + sum((x(1:end-1,:)-1).^2,1);


% DONE

function [Fval, Ftrue] = elli1e3gauss(x)
  parbeta = 1;
  funcID = 102; 
  Ftrue = 10.^(3.*(0:1./(DIM-1):1)) * x.^2; %%% compute function value 
  Fval = Ftrue .* exp(parbeta*randn(1,POPSI)); %%% with noise

  