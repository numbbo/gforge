function Data = datainput_bbob(dimension, nameOfFgeneric)
%DATAINPUT_BBOB is a wrapper for providing the functionality of the
% Comparing Continuous Optimizers (Coco) platform to MATSuMoTo
%--------------------------------------------------------------------------
%Copyright (c) 2014 by Dimo Brockhoff
%
%This file is part of MATSuMoTo.m - the MATLAB Surrogate Model Toolbox
%MATSuMoTo is free software: you can redistribute it and/or modify it under
%the terms of the GNU General Public License as published by the Free 
%Software Foundation, either version 3 of the License, or (at your option) 
%any later version.
%
%MATSuMoTo is distributed in the hope that it will be useful, but WITHOUT 
%ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or 
%FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for 
%more details.
%
%You should have received a copy of the GNU General Public License along 
%with MATSuMoTo.  If not, see <http://www.gnu.org/licenses/>.
%--------------------------------------------------------------------------
%Author information
% Dimo Brockhoff
%researchers.lille.inria.fr/~brockhof/
%--------------------------------------------------------------------------
%
%Input: None
%Output: Data - structure with optimization problem information
%--------------------------------------------------------------------------
%

persistent DIM
persistent MYFUN

if nargin >= 1     % corresponds to init
  DIM = dimension;
  MYFUN = nameOfFgeneric;
end
if nargin < 1      % needed when MATSuMoTo is calling
  dimension = DIM;
  myfunparam = MYFUN;
end

%addpath('./matlab');  % should point to fgeneric.m etc.
Data.dim = DIM; %problem dimension
Data.xlow = -5*ones(1,DIM); %variable lower bounds
Data.xup = 5*ones(1,DIM); %variable upper bounds

Data.integer = []; %indices of integer variables
Data.continuous = (1:DIM); %indices of continuous variables
%objective function
Data.objfunction = MYFUN; %objective function handle
end %function