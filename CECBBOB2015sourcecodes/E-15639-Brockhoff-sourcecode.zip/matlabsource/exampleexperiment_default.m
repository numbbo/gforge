% runs an entire experiment for benchmarking MY_OPTIMIZER
% on the noise-free testbed. fgeneric.m and benchmarks.m
% must be in the path of Matlab/Octave
% CAPITALIZATION indicates code adaptations to be made

addpath('./coco/matlab');  % should point to fgeneric.m etc.
addpath('./coco/'); % points to MATSuMoTo objective function
datapath = 'MATSuMoToDefault-50D';  % different folder for each experiment
opt.algName = 'MATSuMoToDefault-50D';
opt.comments = 'Default arguments of MATSuMoTo library';

dimensions = [2, 3, 5, 10, 20];  % small dimensions first, for CPU reasons
functions = benchmarks('FunctionIndices');  % or benchmarksnoisy(...)
instances = [1:5, 41:50];  % 15 function instances

more off;  % in octave pagination is on by default

t0 = clock;
rand('state', sum(100 * t0));

for dim = dimensions

  maxfunevals = '50 * dim';
  initialDesignSize = 2 * (dim + 1); % default: 2*(dim + 1)
  minfunevals = 'dim + 2';  % PUT MINIMAL SENSIBLE NUMBER OF EVALUATIONS for a restart
  maxrestarts = 1e4;        % SET to zero for an entirely deterministic algorithm

  for ifun = functions
    for iinstance = instances
        % initialize fgeneric of Coco:
        fgeneric('initialize', ifun, iinstance, datapath, opt)
disp('beginning..........')
      
      % independent restarts until maxfunevals or ftarget is reached
      for restarts = 0:maxrestarts
        if restarts > 0  % write additional restarted info
          fgeneric('restart', 'independent restart')
        end
        

	disp('start MATSuMoTo run');

        % MATSuMoTo(data_file,dim,pointerToFgeneric,maxeval,surogate_model,sampling_technique,...
        % initial_design,number_startpoints,starting_point,NumberNewSamples);
        MATSuMoTo('datainput_bbob',...
            dim, ...
            'fgeneric', ...
            eval(maxfunevals) - fgeneric('evaluations')...
		);%,...
            %'RBFcub',... % surrogate model
            %'CANDglob',... % sampling technique
            %'LHS',... % initial design
            %initialDesignSize,... % #startpoints
            %[],... % starting points not specified
            %1 ... % #newsamplesbb
            %);

	disp('next MATSuMoTo run ended...')

        
        if fgeneric('fbest') < fgeneric('ftarget') || ...
           fgeneric('evaluations') + eval(minfunevals) > eval(maxfunevals)
          break;
        end  
      end

      disp(sprintf(['  f%d in %d-D, instance %d: FEs=%d with %d restarts,' ...
                    ' fbest-ftarget=%.4e, elapsed time [h]: %.2f'], ...
                   ifun, dim, iinstance, ...
                   fgeneric('evaluations'), ...
                   restarts, ...
                   fgeneric('fbest') - fgeneric('ftarget'), ...
                   etime(clock, t0)/60/60));

      fgeneric('finalize');
    end
    disp(['      date and time: ' num2str(clock, ' %.0f')]);
  end
  disp(sprintf('---- dimension %d-D done ----', dim));
end

